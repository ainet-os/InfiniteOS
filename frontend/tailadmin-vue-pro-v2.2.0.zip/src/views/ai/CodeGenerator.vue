<template>
  <AdminLayout>
    <AiPageBreadcrumb :pageTitle="currentPageTitle" />
    <AiLayout>
      <CodeGeneratorContent />
    </AiLayout>
  </AdminLayout>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import AdminLayout from '@/components/layout/AdminLayout.vue'
import AiPageBreadcrumb from '@/components/ai/AiPageBreadcrumb.vue'
import AiLayout from '@/components/ai/AiLayout.vue'
import CodeGeneratorContent from '@/components/ai/CodeGeneratorContent.vue'

const currentPageTitle = ref('Code Generator')
</script>
