<template>
  <AdminLayout>
    <AiPageBreadcrumb :pageTitle="currentPageTitle" />
    <AiLayout>
      <ImageGeneratorContent />
    </AiLayout>
  </AdminLayout>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import AdminLayout from '@/components/layout/AdminLayout.vue'
import AiPageBreadcrumb from '@/components/ai/AiPageBreadcrumb.vue'
import AiLayout from '@/components/ai/AiLayout.vue'
import ImageGeneratorContent from '@/components/ai/ImageGeneratorContent.vue'

const currentPageTitle = ref('Image Generator')
</script>
