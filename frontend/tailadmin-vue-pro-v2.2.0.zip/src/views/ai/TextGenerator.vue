<template>
  <AdminLayout>
    <AiPageBreadcrumb :pageTitle="currentPageTitle" />
    <AiLayout>
      <TextGeneratorContent />
    </AiLayout>
  </AdminLayout>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import AdminLayout from '@/components/layout/AdminLayout.vue'
import AiPageBreadcrumb from '@/components/ai/AiPageBreadcrumb.vue'
import AiLayout from '@/components/ai/AiLayout.vue'
import TextGeneratorContent from '@/components/ai/TextGeneratorContent.vue'

const currentPageTitle = ref('Text Generator')
</script>
