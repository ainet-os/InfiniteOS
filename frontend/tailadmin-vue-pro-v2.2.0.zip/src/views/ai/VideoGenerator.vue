<template>
  <AdminLayout>
    <AiPageBreadcrumb :pageTitle="currentPageTitle" />
    <AiLayout>
      <VideoGeneratorContent />
    </AiLayout>
  </AdminLayout>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import AdminLayout from '@/components/layout/AdminLayout.vue'
import AiPageBreadcrumb from '@/components/ai/AiPageBreadcrumb.vue'
import AiLayout from '@/components/ai/AiLayout.vue'
import VideoGeneratorContent from '@/components/ai/VideoGeneratorContent.vue'

const currentPageTitle = ref('Video Generator')
</script>
