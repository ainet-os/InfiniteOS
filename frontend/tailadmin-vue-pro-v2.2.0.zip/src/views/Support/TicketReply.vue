<template>
  <AdminLayout>
    <PageBreadcrumb pageTitle="Ticket Reply" />
    <div class="overflow-hidden xl:h-[calc(100vh-180px)]">
      <div class="grid h-full grid-cols-1 gap-5 xl:grid-cols-12">
        <div class="xl:col-span-8 2xl:col-span-9">
          <TicketReplyContent />
        </div>
        <div class="xl:col-span-4 2xl:col-span-3">
          <TicketDetails />
        </div>
      </div>
    </div>
  </AdminLayout>
</template>

<script setup lang="ts">
import AdminLayout from '@/components/layout/AdminLayout.vue'
import PageBreadcrumb from '@/components/common/PageBreadcrumb.vue'
import TicketDetails from '@/components/support/TicketDetails.vue'
import TicketReplyContent from '@/components/support/TicketReplyContent.vue'
</script>
