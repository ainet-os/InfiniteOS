<template>
  <AdminLayout>
    <PageBreadcrumb pageTitle="Support Tickets" />
    <SupportMetrics />
    <SupportTicketsList />
  </AdminLayout>
</template>

<script setup lang="ts">
import AdminLayout from '@/components/layout/AdminLayout.vue'
import PageBreadcrumb from '@/components/common/PageBreadcrumb.vue'
import SupportMetrics from '@/components/support/SupportMetrics.vue'
import SupportTicketsList from '@/components/support/SupportTicketsList.vue'
</script>
