<template>
  <AdminLayout>
    <PageBreadcrumb :pageTitle="currentPageTitle" />

    <div class="grid grid-cols-1 gap-6">
      <ComponentCard
        title="物流管理仪表板"
        subtitle="即将推出 - 物流管理功能模块正在开发中"
      >
        <div class="text-center py-12">
          <div class="w-16 h-16 mx-auto mb-4 bg-blue-100 rounded-full flex items-center justify-center">
            <svg class="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
            </svg>
          </div>
          <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-2">
            物流管理模块
          </h3>
          <p class="text-gray-500 dark:text-gray-400 mb-6">
            配送跟踪、车队管理、配送统计等功能正在开发中...
          </p>
          <div class="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-md">
            <span class="mr-2">🚚</span>
            即将推出
          </div>
        </div>
      </ComponentCard>
    </div>
  </AdminLayout>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import AdminLayout from '@/components/layout/AdminLayout.vue'
import PageBreadcrumb from '@/components/common/PageBreadcrumb.vue'
import ComponentCard from '@/components/common/ComponentCard.vue'

const currentPageTitle = ref('物流管理')
</script>
