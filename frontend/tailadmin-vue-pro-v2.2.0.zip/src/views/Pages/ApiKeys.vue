<template>
  <AdminLayout>
    <PageBreadcrumb pageTitle="API Keys" />
    <ApiKeyTable />
  </AdminLayout>
</template>

<script setup lang="ts">
import AdminLayout from '@/components/layout/AdminLayout.vue'
import PageBreadcrumb from '@/components/common/PageBreadcrumb.vue'
import ApiKeyTable from '@/components/ecommerce/ApiKeyTable.vue'
</script>
