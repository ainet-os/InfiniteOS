<template>
  <AdminLayout>
    <div class="space-y-6">
      <!-- Logistics Metrics -->
      <LogisticsMetrics />

      <!-- Main Grid Layout -->
      <div class="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <!-- Left Column (2/3 width) -->
        <div class="space-y-6 lg:col-span-2">
          <!-- Delivery Statistics Chart -->
          <DeliveryStatisticsChart />

          <!-- Revenue and Vehicle Charts -->
          <div class="grid gap-6 sm:grid-cols-2">
            <RevenueEarnedChart />
            <DeliveryVehicle />
          </div>
        </div>

        <!-- Right Column (1/3 width) -->
        <div class="lg:col-span-1">
          <div class="flex h-full flex-col rounded-xl border bg-gray-100 dark:border-gray-800 dark:bg-white/3 px-2 py-3 space-y-3">
            <TrackingDeliveryMap />
            <TrackingProgress />
            <DeliveryMan />
          </div>
        </div>
      </div>

      <!-- Delivery Activity Table -->
      <DeliveryActivityTable />
    </div>
  </AdminLayout>
</template>

<script setup lang="ts">
import AdminLayout from '@/components/layout/AdminLayout.vue'
import LogisticsMetrics from '@/components/logistics/LogisticsMetrics.vue'
import DeliveryStatisticsChart from '@/components/logistics/DeliveryStatisticsChart.vue'
import RevenueEarnedChart from '@/components/logistics/RevenueEarnedChart.vue'
import DeliveryVehicle from '@/components/logistics/DeliveryVehicle.vue'
import TrackingDeliveryMap from '@/components/logistics/TrackingDeliveryMap.vue'
import TrackingProgress from '@/components/logistics/TrackingProgress.vue'
import DeliveryMan from '@/components/logistics/DeliveryMan.vue'
import DeliveryActivityTable from '@/components/logistics/DeliveryActivityTable.vue'

defineOptions({
  name: 'LogisticsPage'
})
</script>
