<template>
  <AdminLayout>
    <IntegrationBreadcrumb pageTitle="Integrations" />
    <div class="grid grid-cols-1 gap-5 sm:grid-cols-2 xl:grid-cols-3">
      <IntegrationCard
        v-for="item in integrationData"
        :key="item.id"
        :title="item.title"
        :iconName="item.iconName"
        :description="item.description"
        :connect="item.connect"
        @remove="removeIntegration(item.id)"
      />
    </div>
  </AdminLayout>
</template>

<script setup lang="ts">
import { reactive } from 'vue'
import AdminLayout from '@/components/layout/AdminLayout.vue'
import IntegrationBreadcrumb from '@/components/integration/IntegrationBreadcrumb.vue'
import IntegrationCard from '@/components/integration/IntegrationCard.vue'

// Define component name to satisfy linting requirements
defineOptions({
  name: 'IntegrationsPage'
})

interface Integration {
  id: string
  title: string
  description: string
  iconName: string
  connect: boolean
}

const integrationData = reactive<Integration[]>([
  {
    id: "mailchimp",
    title: "Mailchimp",
    description:
      "Connect Mailchimp to streamline your email marketing—automate campaigns.",
    iconName: "mailchimp",
    connect: true,
  },
  {
    id: "gmeet",
    title: "Google Meet",
    description:
      "Connect your Google Meet account for seamless video conferencing.",
    iconName: "gmeet",
    connect: false,
  },
  {
    id: "zoom",
    title: "Zoom",
    description:
      "Integrate Zoom to streamline your virtual meetings and team collaborations",
    iconName: "zoom",
    connect: false,
  },
  {
    id: "loom",
    title: "Loom",
    description:
      "Integrate Loom to easily record, share, and manage video messages",
    iconName: "loom",
    connect: false,
  },
  {
    id: "linear",
    title: "Linear",
    description:
      "Integrate Linear to manage issues, track progress, and streamline your team's.",
    iconName: "linear",
    connect: false,
  },
  {
    id: "gmail",
    title: "Gmail",
    description:
      "Integrate Gmail to send, receive, and manage emails directly from your workspace.",
    iconName: "gmail",
    connect: false,
  },
  {
    id: "trello",
    title: "Trello",
    description: "Capture, organize, and tackle your to-dos from anywhere.",
    iconName: "trello",
    connect: false,
  },
  {
    id: "notion",
    title: "Notion",
    description: "Capture, organize, and tackle your to-dos from anywhere.",
    iconName: "notion",
    connect: false,
  },
  {
    id: "jira",
    title: "Jira",
    description:
      "Track issues and manage projects with ease and full team visibility.",
    iconName: "jira",
    connect: false,
  },
])

const removeIntegration = (id: string) => {
  const index = integrationData.findIndex(item => item.id === id)
  if (index !== -1) {
    integrationData.splice(index, 1)
  }
}
</script>
