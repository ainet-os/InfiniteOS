<template>
  <AdminLayout>
    <PageBreadcrumb :pageTitle="currentPageTitle" />
    <div class="mb-6 flex flex-col gap-6 xl:flex-row">
      <BillingPlan />
      <BillingInfo />
    </div>
    <PaymentMethod />
    <InvoiceTable />
  </AdminLayout>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import AdminLayout from '@/components/layout/AdminLayout.vue'
import PageBreadcrumb from '@/components/common/PageBreadcrumb.vue'
import BillingPlan from '@/components/ecommerce/billing/BillingPlan.vue'
import BillingInfo from '@/components/ecommerce/billing/BillingInfo.vue'
import PaymentMethod from '@/components/ecommerce/billing/PaymentMethod.vue'
import InvoiceTable from '@/components/ecommerce/billing/InvoiceTable.vue'

const currentPageTitle = ref('Billing')
</script>
