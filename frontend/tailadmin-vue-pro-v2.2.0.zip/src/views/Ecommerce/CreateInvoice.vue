<template>
  <AdminLayout>
    <PageBreadcrumb :pageTitle="currentPageTitle" />
    <CreateInvoiceForm />
  </AdminLayout>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import AdminLayout from '@/components/layout/AdminLayout.vue'
import PageBreadcrumb from '@/components/common/PageBreadcrumb.vue'
import CreateInvoiceForm from '@/components/ecommerce/CreateInvoiceForm.vue'

const currentPageTitle = ref('Create Invoice')
</script>
