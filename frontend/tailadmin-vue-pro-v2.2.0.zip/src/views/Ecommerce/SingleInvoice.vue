<template>
  <AdminLayout>
    <InvoiceMain />
  </AdminLayout>
</template>

<script setup lang="ts">
import AdminLayout from '@/components/layout/AdminLayout.vue'
import InvoiceMain from '@/components/ecommerce/InvoiceMain.vue'
</script>
