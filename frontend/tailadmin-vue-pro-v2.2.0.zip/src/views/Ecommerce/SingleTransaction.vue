<template>
  <AdminLayout>
    <PageBreadcrumb :pageTitle="currentPageTitle" />
    <div class="space-y-6">
      <TransactionHeader />
      <div class="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <div class="lg:col-span-8 2xl:col-span-9">
          <OrderDetailsTable />
        </div>
        <div class="space-y-6 lg:col-span-4 2xl:col-span-3">
          <CustomerDetails />
          <OrderHistory />
        </div>
      </div>
    </div>
  </AdminLayout>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import AdminLayout from '@/components/layout/AdminLayout.vue'
import PageBreadcrumb from '@/components/common/PageBreadcrumb.vue'
import TransactionHeader from '@/components/ecommerce/TransactionHeader.vue'
import OrderDetailsTable from '@/components/ecommerce/OrderDetailsTable.vue'
import CustomerDetails from '@/components/ecommerce/CustomerDetails.vue'
import OrderHistory from '@/components/ecommerce/OrderHistory.vue'

const currentPageTitle = ref('Single Transaction')
</script>
