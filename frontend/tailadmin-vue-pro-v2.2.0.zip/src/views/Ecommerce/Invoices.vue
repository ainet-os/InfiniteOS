<template>
  <AdminLayout>
    <PageBreadcrumb :pageTitle="currentPageTitle" />
    <InvoiceMetrics />
    <InvoiceListTable />
  </AdminLayout>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import AdminLayout from '@/components/layout/AdminLayout.vue'
import PageBreadcrumb from '@/components/common/PageBreadcrumb.vue'
import InvoiceMetrics from '@/components/ecommerce/InvoiceMetrics.vue'
import InvoiceListTable from '@/components/ecommerce/InvoiceListTable.vue'

const currentPageTitle = ref('Invoices')
</script>
