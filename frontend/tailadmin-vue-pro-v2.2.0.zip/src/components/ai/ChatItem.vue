<template>
  <li class="group relative rounded-full px-3 py-1.5 hover:bg-gray-50 dark:hover:bg-gray-950">
    <div class="flex cursor-pointer items-center justify-between">
      <a
        href="#"
        class="block truncate text-sm text-gray-700 dark:text-white/90"
      >
        {{ chat.title }}
      </a>

      <!-- 3-dot menu button -->
      <button
        @click="$emit('toggleDropdown')"
        class="invisible ml-2 rounded-full p-1 text-gray-700 group-hover:visible hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-400"
      >
        <svg
          xmlns:xlink="http://www.w3.org/1999/xlink"
          width="18"
          height="18"
          viewBox="0 0 24 24"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            fillRule="evenodd"
            clipRule="evenodd"
            d="M5.99902 10.4951C6.82745 10.4951 7.49902 11.1667 7.49902 11.9951V12.0051C7.49902 12.8335 6.82745 13.5051 5.99902 13.5051C5.1706 13.5051 4.49902 12.8335 4.49902 12.0051V11.9951C4.49902 11.1667 5.1706 10.4951 5.99902 10.4951ZM17.999 10.4951C18.8275 10.4951 19.499 11.1667 19.499 11.9951V12.0051C19.499 12.8335 18.8275 13.5051 17.999 13.5051C17.1706 13.5051 16.499 12.8335 16.499 12.0051V11.9951C16.499 11.1667 17.1706 10.4951 17.999 10.4951ZM13.499 11.9951C13.499 11.1667 12.8275 10.4951 11.999 10.4951C11.1706 10.4951 10.499 11.1667 10.499 11.9951V12.0051C10.499 12.8335 11.1706 13.5051 11.999 13.5051C12.8275 13.5051 13.499 12.8335 13.499 12.0051V11.9951Z"
            fill="#98A2B3"
          />
        </svg>
      </button>
    </div>

    <!-- Dropdown menu -->
    <div
      v-if="isOpen"
      class="absolute right-0 z-20 mt-1 w-32 rounded-lg border border-gray-200 bg-white p-1 shadow-xs dark:border-gray-800 dark:bg-gray-900"
    >
      <ul class="text-sm text-gray-700 dark:text-gray-400">
        <li>
          <button
            @click="$emit('rename')"
            class="block w-full rounded-md px-3 py-1.5 text-left hover:bg-gray-100 hover:text-gray-800 dark:hover:bg-gray-800 dark:hover:text-white/90"
          >
            Rename
          </button>
        </li>
        <li>
          <button
            @click="$emit('delete')"
            class="block w-full rounded-md px-3 py-1.5 text-left hover:bg-gray-100 hover:text-gray-800 dark:hover:bg-gray-800 dark:hover:text-white/90"
          >
            Delete
          </button>
        </li>
      </ul>
    </div>
  </li>
</template>

<script setup lang="ts">
interface ChatItemType {
  id: string
  title: string
}

interface Props {
  chat: ChatItemType
  isOpen: boolean
}

defineProps<Props>()

defineEmits<{
  toggleDropdown: []
  rename: []
  delete: []
}>()
</script>
