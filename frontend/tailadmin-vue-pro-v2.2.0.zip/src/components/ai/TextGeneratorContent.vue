<template>
  <div class="custom-scrollbar relative z-20 max-h-[50vh] flex-1 mx-auto space-y-7 w-full overflow-y-auto pb-10 lg:pb-7">
    <!-- User Message -->
    <div class="flex justify-end">
      <div class="shadow-theme-xs bg-brand-100 dark:bg-brand-500/20 max-w-[480px] rounded-xl rounded-tr-xs px-4 py-3">
        <p class="text-left text-sm font-normal text-gray-800 dark:text-white/90">
          Can you generate some random, creative, and engaging placeholder
          text for me? It doesn&apos;t need to follow any specific
          structure—just something fun or interesting to fill space
          temporarily.
        </p>
      </div>
    </div>

    <!-- AI Response -->
    <div class="flex justify-start">
      <div>
        <div class="shadow-theme-xs max-w-[480px] rounded-xl rounded-tl-xs bg-gray-100 px-4 py-3 dark:bg-white/5">
          <p class="mb-5 text-sm leading-5 text-gray-800 dark:text-white/90">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus
            et varius tortor. Aenean dui magna, vehicula in lacinia non,
            euismod sed odio. Aliquam erat volutpat.
          </p>
          <p class="mb-5 text-sm leading-5 text-gray-800 dark:text-white/90">
            Integer iaculis eu tellus vel tincidunt. Sed sed dictum orci, in
            pretium erat. Proin ut mi a arcu mollis hendrerit. Ut id est
            finibus, egestas tellus ac, pharetra ante.
          </p>
        </div>
        <div class="mt-3">
          <CopyButton :textToCopy="firstResponse" />
        </div>
      </div>
    </div>

    <!-- User Message -->
    <div class="flex justify-end">
      <div class="shadow-theme-xs bg-brand-100 dark:bg-brand-500/20 max-w-[480px] rounded-xl rounded-tr-xs px-4 py-3">
        <p class="text-left text-sm font-normal text-gray-800 dark:text-white/90">
          I&apos;m looking for a block of random, imaginative text—something
          quirky or unexpected to use as placeholder content.
        </p>
      </div>
    </div>

    <!-- AI Response -->
    <div class="flex justify-start">
      <div>
        <div class="shadow-theme-xs max-w-[480px] rounded-xl rounded-tl-xs bg-gray-100 px-4 py-3 dark:bg-white/5">
          <p class="mb-5 text-sm leading-5 text-gray-800 dark:text-white/90">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus
            et varius tortor. Aenean dui magna, vehicula in lacinia non,
            euismod sed odio. Aliquam erat volutpat. Integer iaculis eu tellus
            vel tincidunt. Sed sed dictum orci, in pretium erat.
          </p>
          <p class="mb-5 text-sm leading-5 text-gray-800 dark:text-white/90">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus
            et varius tortor.
          </p>
        </div>
        <div class="mt-3">
          <CopyButton :textToCopy="secondResponse" />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import CopyButton from './CopyButton.vue'

// Sample chat data
const firstResponse =
  "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus et varius tortor. Aenean dui magna, vehicula in lacinia non, euismod sed odio. Aliquam erat volutpat. Integer iaculis eu tellus vel tincidunt. Sed sed dictum orci, in pretium erat. Proin ut mi a arcu mollis hendrerit. Ut id est finibus, egestas tellus ac, pharetra ante."

const secondResponse =
  "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus et varius tortor. Aenean dui magna, vehicula in lacinia non, euismod sed odio. Aliquam erat volutpat. Integer iaculis eu tellus vel tincidunt. Sed sed dictum orci, in pretium erat. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus et varius tortor."
</script>
