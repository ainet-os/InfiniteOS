<template>
  <div class="relative">
    <input
      :type="type"
      :id="id"
      :name="name"
      :placeholder="placeholder"
      :value="modelValue"
      @input="handleInput"
      :min="min"
      :max="max"
      :step="step"
      :disabled="disabled"
      :class="inputClasses"
    />

    <p
      v-if="hint"
      :class="`mt-1.5 text-xs ${
        error
          ? 'text-error-500'
          : success
          ? 'text-success-500'
          : 'text-gray-500'
      }`"
    >
      {{ hint }}
    </p>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'

interface InputProps {
  type?: 'text' | 'number' | 'email' | 'password' | 'date' | 'time' | string
  id?: string
  name?: string
  placeholder?: string
  modelValue?: string | number
  className?: string
  min?: string
  max?: string
  step?: number
  disabled?: boolean
  success?: boolean
  error?: boolean
  hint?: string
}

const props = withDefaults(defineProps<InputProps>(), {
  type: 'text',
  className: '',
  disabled: false,
  success: false,
  error: false
})

const emit = defineEmits<{
  'update:modelValue': [value: string | number]
}>()

const handleInput = (event: Event) => {
  const target = event.target as HTMLInputElement
  const value = props.type === 'number' ? Number(target.value) : target.value
  emit('update:modelValue', value)
}

const inputClasses = computed(() => {
  let classes = `h-11 w-full rounded-lg border appearance-none px-4 py-2.5 text-sm shadow-theme-xs placeholder:text-gray-400 focus:outline-hidden focus:ring-3 dark:bg-gray-900 dark:text-white/90 dark:placeholder:text-white/30 ${props.className}`

  if (props.disabled) {
    classes += ` text-gray-500 border-gray-300 opacity-40 bg-gray-100 cursor-not-allowed dark:bg-gray-800 dark:text-gray-400 dark:border-gray-700 opacity-40`
  } else if (props.error) {
    classes += ` border-error-500 focus:border-error-300 focus:ring-error-500/20 dark:text-error-400 dark:border-error-500 dark:focus:border-error-800`
  } else if (props.success) {
    classes += ` border-success-500 focus:border-success-300 focus:ring-success-500/20 dark:text-success-400 dark:border-success-500 dark:focus:border-success-800`
  } else {
    classes += ` bg-transparent text-gray-800 border-gray-300 focus:border-brand-300 focus:ring-brand-500/20 dark:border-gray-700 dark:text-white/90 dark:focus:border-brand-800`
  }

  return classes
})
</script>
