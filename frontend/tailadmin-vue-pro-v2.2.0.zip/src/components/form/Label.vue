<template>
  <label
    :for="htmlFor"
    :class="labelClasses"
  >
    <slot></slot>
  </label>
</template>

<script setup lang="ts">
import { computed } from 'vue'

interface LabelProps {
  htmlFor?: string
  className?: string
}

const props = withDefaults(defineProps<LabelProps>(), {
  className: ''
})

const labelClasses = computed(() => {
  const defaultClasses = 'mb-1.5 block text-sm font-medium text-gray-700 dark:text-gray-400'
  return `${defaultClasses} ${props.className}`.trim()
})
</script>
