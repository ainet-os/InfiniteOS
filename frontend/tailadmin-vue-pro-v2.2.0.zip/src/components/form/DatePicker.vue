<template>
  <div class="relative">
    <input
      type="date"
      :id="id"
      :name="name"
      :value="modelValue"
      @input="handleInput"
      :disabled="disabled"
      :class="inputClasses"
      :placeholder="placeholder"
    />
    <div class="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none">
      <svg
        width="20"
        height="20"
        viewBox="0 0 20 20"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        class="text-gray-500 dark:text-gray-400"
      >
        <path
          d="M6.66699 1.66675V4.16675M13.3337 1.66675V4.16675M2.50033 7.50008H17.5003M4.16699 3.33341H15.8337C16.7541 3.33341 17.5003 4.07961 17.5003 5.00008V16.6667C17.5003 17.5872 16.7541 18.3334 15.8337 18.3334H4.16699C3.24652 18.3334 2.50033 17.5872 2.50033 16.6667V5.00008C2.50033 4.07961 3.24652 3.33341 4.16699 3.33341Z"
          stroke="currentColor"
          stroke-width="1.5"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
      </svg>
    </div>

    <p
      v-if="hint"
      :class="`mt-1.5 text-xs ${
        error
          ? 'text-error-500'
          : success
          ? 'text-success-500'
          : 'text-gray-500'
      }`"
    >
      {{ hint }}
    </p>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'

interface DatePickerProps {
  id?: string
  name?: string
  placeholder?: string
  modelValue?: string
  className?: string
  disabled?: boolean
  success?: boolean
  error?: boolean
  hint?: string
}

const props = withDefaults(defineProps<DatePickerProps>(), {
  className: '',
  disabled: false,
  success: false,
  error: false,
  placeholder: '年/月/日'
})

const emit = defineEmits<{
  'update:modelValue': [value: string]
}>()

const handleInput = (event: Event) => {
  const target = event.target as HTMLInputElement
  emit('update:modelValue', target.value)
}

const inputClasses = computed(() => {
  let classes = `h-11 w-full rounded-lg border appearance-none px-4 py-2.5 pr-12 text-sm shadow-theme-xs placeholder:text-gray-400 focus:outline-hidden focus:ring-3 dark:bg-gray-900 dark:text-white/90 dark:placeholder:text-white/30 ${props.className}`

  if (props.disabled) {
    classes += ` text-gray-500 border-gray-300 opacity-40 bg-gray-100 cursor-not-allowed dark:bg-gray-800 dark:text-gray-400 dark:border-gray-700 opacity-40`
  } else if (props.error) {
    classes += ` border-error-500 focus:border-error-300 focus:ring-error-500/20 dark:text-error-400 dark:border-error-500 dark:focus:border-error-800`
  } else if (props.success) {
    classes += ` border-success-500 focus:border-success-300 focus:ring-success-500/20 dark:text-success-400 dark:border-success-500 dark:focus:border-success-800`
  } else {
    classes += ` bg-transparent text-gray-800 border-gray-300 focus:border-brand-300 focus:ring-brand-500/20 dark:border-gray-700 dark:text-white/90 dark:focus:border-brand-800`
  }

  return classes
})
</script>
