<template>
  <article class="rounded-2xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-white/[0.03]">
    <div class="relative p-5 pb-9">
      <div class="mb-5 inline-flex h-10 w-10 items-center justify-center">
        <IntegrationIcons :name="iconName" />
      </div>
      <h3 class="mb-3 text-lg font-semibold text-gray-800 dark:text-white/90">
        {{ title }}
      </h3>
      <p class="max-w-xs text-sm text-gray-500 dark:text-gray-400">
        {{ description }}
      </p>
      <div class="absolute top-5 right-5 h-fit">
        <SimpleDropdown>
          <button
            class="flex w-full font-normal text-left text-gray-500 rounded-lg hover:bg-gray-100 hover:text-gray-700 dark:text-gray-400 dark:hover:bg-white/5 dark:hover:text-gray-300 px-3 py-2 text-sm"
            @click="handleRemove"
          >
            Remove
          </button>
        </SimpleDropdown>
      </div>
    </div>

    <div class="flex items-center justify-between border-t border-gray-200 p-5 dark:border-gray-800">
      <div class="flex gap-3">
        <IntegrationSettingsModal />
        <IntegrationDetailsModal />
      </div>
      <Switch v-model="isConnected" />
    </div>
  </article>

  <IntegrationDeleteModal
    :isOpen="deleteModal.isOpen.value"
    @close="deleteModal.closeModal"
    @confirm="confirmDelete"
  />
</template>

<script setup lang="ts">
import { ref } from 'vue'
import IntegrationIcons from './IntegrationIcons.vue'
import SimpleDropdown from '@/components/common/SimpleDropdown.vue'
import Switch from '@/components/ui/Switch.vue'
import IntegrationSettingsModal from './IntegrationSettingsModal.vue'
import IntegrationDetailsModal from './IntegrationDetailsModal.vue'
import IntegrationDeleteModal from './IntegrationDeleteModal.vue'
import { useModal } from '@/composables/useModal'

interface IntegrationCardProps {
  title: string
  iconName: string
  description: string
  connect: boolean
}

const props = defineProps<IntegrationCardProps>()
const emit = defineEmits<{
  remove: []
}>()

const isConnected = ref(props.connect)
const deleteModal = useModal()

const handleRemove = () => {
  deleteModal.openModal()
}

const confirmDelete = () => {
  emit('remove')
}
</script>
