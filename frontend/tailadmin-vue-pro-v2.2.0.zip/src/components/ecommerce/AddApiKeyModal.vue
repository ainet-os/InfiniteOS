<template>
  <div>
    <Button @click="addApiKeyModal.openModal" :startIcon="true">
      <template #startIcon>
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="20"
          height="20"
          viewBox="0 0 20 20"
          fill="none"
        >
          <path
            d="M5 10.0002H15.0006M10.0002 5V15.0006"
            stroke="white"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
          />
        </svg>
      </template>
      Add API Key
    </Button>

    <Modal
      :isOpen="addApiKeyModal.isOpen.value"
      @close="addApiKeyModal.closeModal"
      className="relative w-full max-w-[600px] m-5 sm:m-0 rounded-3xl bg-white p-6 lg:p-10 dark:bg-gray-900"
    >
      <div>
        <h4 class="text-title-sm mb-1 font-semibold text-gray-800 dark:text-white/90">
          Generate API key
        </h4>
        <p class="mb-7 text-sm leading-6 text-gray-500 dark:text-gray-400">
          To enable secure access to the web services, your app requires an
          API key with permissions for resources such as the S3 bucket.
        </p>
        <form @submit.prevent>
          <div>
            <Label>Enter your application name</Label>
            <InputField
              v-model="applicationName"
              type="text"
              placeholder="Application name"
            />
          </div>
          <p class="mt-4 text-sm text-gray-500 dark:text-gray-400">
            Naming your application makes it easier to recognize your API key
            in the future.
          </p>
        </form>
        <div class="mt-8 flex w-full flex-col sm:flex-row items-center justify-between gap-3">
          <Button
            variant="outline"
            className="w-full"
            @click="addApiKeyModal.closeModal"
          >
            Close
          </Button>
          <Button
            className="w-full"
            @click="generateApiKey"
          >
            Generate API key
          </Button>
        </div>
      </div>
    </Modal>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import Button from '@/components/ui/Button.vue'
import Modal from '@/components/ui/Modal.vue'
import Label from '@/components/form/Label.vue'
import InputField from '@/components/form/InputField.vue'
import { useModal } from '@/composables/useModal'

const addApiKeyModal = useModal()
const applicationName = ref('Saasbold')

const generateApiKey = () => {
  // TODO: Implement API key generation logic
  console.log('Generating API key for:', applicationName.value)
  addApiKeyModal.closeModal()
}
</script>
