<template>
  <div class="rounded-2xl border border-gray-200 bg-white p-6 dark:border-gray-800 dark:bg-white/3">
    <h2 class="mb-5 text-lg font-semibold text-gray-800 dark:text-white/90">
      Customer Details
    </h2>
    <ul class="divide-y divide-gray-100 dark:divide-gray-800">
      <li class="flex items-start gap-5 py-2.5">
        <span class="w-1/2 text-sm text-gray-500 sm:w-1/3 dark:text-gray-400">
          Name
        </span>
        <span class="w-1/2 text-sm text-gray-700 sm:w-2/3 dark:text-gray-400">
          Mushafrof Chowdhury
        </span>
      </li>
      <li class="flex items-start gap-5 py-2.5">
        <span class="w-1/2 text-sm text-gray-500 sm:w-1/3 dark:text-gray-400">
          Email
        </span>
        <span class="w-1/2 text-sm text-gray-700 sm:w-2/3 dark:text-gray-400">
          name@example.com
        </span>
      </li>
      <li class="flex items-start gap-5 py-2.5">
        <span class="w-1/2 text-sm text-gray-500 sm:w-1/3 dark:text-gray-400">
          Phone
        </span>
        <span class="w-1/2 text-sm text-gray-700 sm:w-2/3 dark:text-gray-400">
          Mountain View, CA, 94040
        </span>
      </li>
      <li class="flex items-start gap-5 py-2.5">
        <span class="w-1/2 text-sm text-gray-500 sm:w-1/3 dark:text-gray-400">
          Phone
        </span>
        <span class="w-1/2 text-sm text-gray-700 sm:w-2/3 dark:text-gray-400">
          +123 456 7890
        </span>
      </li>
      <li class="flex items-start gap-5 py-2.5">
        <span class="w-1/2 text-sm text-gray-500 sm:w-1/3 dark:text-gray-400">
          Country
        </span>
        <span class="w-1/2 text-sm text-gray-700 sm:w-2/3 dark:text-gray-400">
          United States
        </span>
      </li>
      <li class="flex items-start gap-5 py-2.5">
        <span class="w-1/2 text-sm text-gray-500 sm:w-1/3 dark:text-gray-400">
          Address
        </span>
        <span class="w-1/2 text-sm text-gray-700 sm:w-2/3 dark:text-gray-400">
          62 Miles Drive St, Newark, NJ 07103, California.
        </span>
      </li>
    </ul>
  </div>
</template>

<script setup lang="ts">
// This component uses static data to match the Next.js version exactly
</script>
