<template>
  <div class="space-y-6">
    <!-- Products Description Section -->
    <div class="rounded-2xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-white/[0.03]">
      <div class="border-b border-gray-200 px-6 py-4 dark:border-gray-800">
        <h2 class="text-lg font-medium text-gray-800 dark:text-white">
          Products Description
        </h2>
      </div>
      <div class="p-4 sm:p-6 dark:border-gray-800">
        <form @submit.prevent="handleSubmit">
          <div class="grid grid-cols-1 gap-5 md:grid-cols-2">
            <div>
              <label class="mb-1 inline-block text-sm font-semibold text-gray-700 dark:text-gray-400">
                Product Name
              </label>
              <input
                v-model="form.name"
                type="text"
                placeholder="Enter product name"
                class="shadow-sm focus:border-brand-300 focus:ring-brand-500/10 dark:focus:border-brand-800 h-11 w-full rounded-lg border border-gray-300 bg-white px-4 py-2.5 text-sm text-gray-800 placeholder:text-gray-400 focus:ring-3 focus:outline-none dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:placeholder:text-white/30"
              />
            </div>
            <div>
              <label class="mb-1 inline-block text-sm font-semibold text-gray-700 dark:text-gray-400">
                Category
              </label>
              <select
                v-model="form.category"
                class="shadow-sm focus:border-brand-300 focus:ring-brand-500/10 dark:focus:border-brand-800 h-11 w-full rounded-lg border border-gray-300 bg-white px-4 py-2.5 text-sm text-gray-800 focus:ring-3 focus:outline-none dark:border-gray-700 dark:bg-gray-900 dark:text-white/90"
              >
                <option value="">Select a category</option>
                <option value="Laptop">Laptop</option>
                <option value="Phone">Phone</option>
                <option value="Watch">Watch</option>
                <option value="Electronics">Electronics</option>
                <option value="Accessories">Accessories</option>
              </select>
            </div>
            <div>
              <label class="mb-1 inline-block text-sm font-semibold text-gray-700 dark:text-gray-400">
                Brand
              </label>
              <select
                v-model="form.brand"
                class="shadow-sm focus:border-brand-300 focus:ring-brand-500/10 dark:focus:border-brand-800 h-11 w-full rounded-lg border border-gray-300 bg-white px-4 py-2.5 text-sm text-gray-800 focus:ring-3 focus:outline-none dark:border-gray-700 dark:bg-gray-900 dark:text-white/90"
              >
                <option value="">Select brand</option>
                <option value="1">Apple</option>
                <option value="2">Samsung</option>
                <option value="3">LG</option>
              </select>
            </div>
            <div>
              <label class="mb-1 inline-block text-sm font-semibold text-gray-700 dark:text-gray-400">
                Color
              </label>
              <select
                v-model="form.color"
                class="shadow-sm focus:border-brand-300 focus:ring-brand-500/10 dark:focus:border-brand-800 h-11 w-full rounded-lg border border-gray-300 bg-white px-4 py-2.5 text-sm text-gray-800 focus:ring-3 focus:outline-none dark:border-gray-700 dark:bg-gray-900 dark:text-white/90"
              >
                <option value="">Select color</option>
                <option value="1">Silver</option>
                <option value="2">Black</option>
                <option value="3">White</option>
                <option value="4">Gray</option>
              </select>
            </div>
            <div class="col-span-full">
              <div class="grid grid-cols-1 gap-5 sm:grid-cols-3">
                <div>
                  <label class="mb-1 inline-block text-sm font-semibold text-gray-700 dark:text-gray-400">
                    Weight(KG)
                  </label>
                  <input
                    v-model="form.weight"
                    type="number"
                    placeholder="15"
                    class="shadow-sm focus:border-brand-300 focus:ring-brand-500/10 dark:focus:border-brand-800 h-11 w-full rounded-lg border border-gray-300 bg-white px-4 py-2.5 text-sm text-gray-800 placeholder:text-gray-400 focus:ring-3 focus:outline-none dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:placeholder:text-white/30"
                  />
                </div>
                <div>
                  <label class="mb-1 inline-block text-sm font-semibold text-gray-700 dark:text-gray-400">
                    Length(CM)
                  </label>
                  <input
                    v-model="form.length"
                    type="number"
                    placeholder="120"
                    class="shadow-sm focus:border-brand-300 focus:ring-brand-500/10 dark:focus:border-brand-800 h-11 w-full rounded-lg border border-gray-300 bg-white px-4 py-2.5 text-sm text-gray-800 placeholder:text-gray-400 focus:ring-3 focus:outline-none dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:placeholder:text-white/30"
                  />
                </div>
                <div>
                  <label class="mb-1 inline-block text-sm font-semibold text-gray-700 dark:text-gray-400">
                    Width(CM)
                  </label>
                  <input
                    v-model="form.width"
                    type="number"
                    placeholder="23"
                    class="shadow-sm focus:border-brand-300 focus:ring-brand-500/10 dark:focus:border-brand-800 h-11 w-full rounded-lg border border-gray-300 bg-white px-4 py-2.5 text-sm text-gray-800 placeholder:text-gray-400 focus:ring-3 focus:outline-none dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:placeholder:text-white/30"
                  />
                </div>
                <div class="col-span-full">
                  <label class="mb-1 inline-block text-sm font-semibold text-gray-700 dark:text-gray-400">
                    Description
                  </label>
                  <textarea
                    v-model="form.description"
                    :rows="6"
                    placeholder="Receipt Info (optional)"
                    class="shadow-sm focus:border-brand-300 focus:ring-brand-500/10 dark:focus:border-brand-800 w-full rounded-lg border border-gray-300 bg-white px-4 py-2.5 text-sm text-gray-800 placeholder:text-gray-400 focus:ring-3 focus:outline-none dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:placeholder:text-white/30"
                  ></textarea>
                </div>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>

    <!-- Pricing & Availability Section -->
    <div class="rounded-2xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-white/[0.03]">
      <div class="border-b border-gray-200 px-6 py-4 dark:border-gray-800">
        <h2 class="text-lg font-medium text-gray-800 dark:text-white">
          Pricing & Availability
        </h2>
      </div>
      <div class="space-y-5 p-4 sm:p-6">
        <div class="grid grid-cols-1 gap-5 sm:grid-cols-3">
          <div>
            <label class="mb-1 inline-block text-sm font-semibold text-gray-700 dark:text-gray-400">
              Weight(KG)
            </label>
            <input
              v-model="form.weight2"
              type="number"
              placeholder="15"
              class="shadow-sm focus:border-brand-300 focus:ring-brand-500/10 dark:focus:border-brand-800 h-11 w-full rounded-lg border border-gray-300 bg-white px-4 py-2.5 text-sm text-gray-800 placeholder:text-gray-400 focus:ring-3 focus:outline-none dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:placeholder:text-white/30"
            />
          </div>
          <div>
            <label class="mb-1 inline-block text-sm font-semibold text-gray-700 dark:text-gray-400">
              Length(CM)
            </label>
            <input
              v-model="form.length2"
              type="number"
              placeholder="120"
              class="shadow-sm focus:border-brand-300 focus:ring-brand-500/10 dark:focus:border-brand-800 h-11 w-full rounded-lg border border-gray-300 bg-white px-4 py-2.5 text-sm text-gray-800 placeholder:text-gray-400 focus:ring-3 focus:outline-none dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:placeholder:text-white/30"
            />
          </div>
          <div>
            <label class="mb-1 inline-block text-sm font-semibold text-gray-700 dark:text-gray-400">
              Width(CM)
            </label>
            <input
              v-model="form.width2"
              type="number"
              placeholder="23"
              class="shadow-sm focus:border-brand-300 focus:ring-brand-500/10 dark:focus:border-brand-800 h-11 w-full rounded-lg border border-gray-300 bg-white px-4 py-2.5 text-sm text-gray-800 placeholder:text-gray-400 focus:ring-3 focus:outline-none dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:placeholder:text-white/30"
            />
          </div>
        </div>
        <div class="grid grid-cols-1 gap-5 sm:grid-cols-2">
          <div>
            <label class="mb-1 inline-block text-sm font-semibold text-gray-700 dark:text-gray-400">
              Stock Quantity
            </label>
            <div class="flex h-11 divide-x divide-gray-300 overflow-hidden rounded-lg border border-gray-300 dark:divide-gray-800 dark:border-gray-700">
              <button
                type="button"
                @click="decrementStock"
                class="inline-flex h-11 w-11 items-center justify-center bg-white text-gray-700 hover:bg-gray-100 dark:border-gray-800 dark:bg-gray-900 dark:text-gray-400 dark:hover:bg-gray-800 dark:hover:text-white"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="25"
                  height="24"
                  viewBox="0 0 25 24"
                  fill="none"
                >
                  <path
                    d="M6.66699 12H18.6677"
                    stroke="currentColor"
                    stroke-width="1.5"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                  />
                </svg>
              </button>
              <div class="flex-1">
                <input
                  v-model="form.stockQuantity"
                  type="text"
                  class="h-full w-full border-0 bg-white text-center text-sm text-gray-700 outline-none focus:ring-0 dark:bg-gray-900 dark:text-gray-400"
                />
              </div>
              <button
                type="button"
                @click="incrementStock"
                class="inline-flex h-11 w-11 items-center justify-center bg-white text-gray-700 hover:bg-gray-100 dark:bg-gray-900 dark:text-gray-400 dark:hover:bg-gray-800 dark:hover:text-white"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="25"
                  height="24"
                  viewBox="0 0 25 24"
                  fill="none"
                >
                  <path
                    d="M6.66699 12.0002H18.6677M12.6672 6V18.0007"
                    stroke="currentColor"
                    stroke-width="1.5"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                  />
                </svg>
              </button>
            </div>
          </div>
          <div>
            <label class="mb-1 inline-block text-sm font-semibold text-gray-700 dark:text-gray-400">
              Availability Status
            </label>
            <select
              v-model="form.availability"
              class="shadow-sm focus:border-brand-300 focus:ring-brand-500/10 dark:focus:border-brand-800 h-11 w-full rounded-lg border border-gray-300 bg-white px-4 py-2.5 text-sm text-gray-800 focus:ring-3 focus:outline-none dark:border-gray-700 dark:bg-gray-900 dark:text-white/90"
            >
              <option value="">Select a Availability</option>
              <option value="1">In Stock</option>
              <option value="2">Out of Stock</option>
            </select>
          </div>
        </div>
      </div>
    </div>

    <!-- Products Images Section -->
    <div class="rounded-2xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-white/[0.03]">
      <div class="border-b border-gray-200 px-6 py-4 dark:border-gray-800">
        <h2 class="text-lg font-medium text-gray-800 dark:text-white">
          Products Images
        </h2>
      </div>
      <div class="p-4 sm:p-6">
        <label
          for="product-image"
          class="shadow-theme-xs group hover:border-brand-500 block cursor-pointer rounded-lg border-2 border-dashed border-gray-300 transition dark:hover:border-brand-400 dark:border-gray-800"
        >
          <div class="flex justify-center p-10">
            <div class="flex max-w-[260px] flex-col items-center gap-4">
              <div class="inline-flex h-13 w-13 items-center justify-center rounded-full border border-gray-200 text-gray-700 transition dark:border-gray-800 dark:text-gray-400">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                >
                  <path
                    d="M20.0004 16V18.5C20.0004 19.3284 19.3288 20 18.5004 20H5.49951C4.67108 20 3.99951 19.3284 3.99951 18.5V16M12.0015 4L12.0015 16M7.37454 8.6246L11.9994 4.00269L16.6245 8.6246"
                    stroke="currentColor"
                    stroke-width="1.5"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                  />
                </svg>
              </div>
              <p class="text-center text-sm text-gray-500 dark:text-gray-400">
                <span class="font-medium text-gray-800 dark:text-white/90">
                  Click to upload
                </span>
                or drag and drop SVG, PNG, JPG or GIF (MAX. 800x400px)
              </p>
            </div>
          </div>
          <input type="file" id="product-image" class="hidden" @change="handleFileUpload" />
        </label>
      </div>
    </div>

    <!-- Action Buttons -->
    <div class="flex flex-col gap-3 sm:flex-row sm:justify-end">
      <button
        type="button"
        class="inline-flex items-center justify-center gap-2 rounded-lg border border-gray-300 px-4 py-3 text-sm font-medium text-gray-700 transition hover:bg-gray-50 dark:border-gray-700 dark:text-gray-300 dark:hover:bg-gray-800"
      >
        Draft
      </button>
      <button
        type="button"
        @click="handleSubmit"
        class="bg-brand-500 inline-flex items-center justify-center gap-2 rounded-lg px-4 py-3 text-sm font-medium text-white transition hover:bg-brand-600"
      >
        Publish Product
      </button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'

interface ProductForm {
  name: string
  category: string
  brand: string
  color: string
  weight: number | null
  length: number | null
  width: number | null
  description: string
  weight2: number | null
  length2: number | null
  width2: number | null
  stockQuantity: number
  availability: string
  image?: File | null
}

const form = ref<ProductForm>({
  name: '',
  category: '',
  brand: '',
  color: '',
  weight: null,
  length: null,
  width: null,
  description: '',
  weight2: null,
  length2: null,
  width2: null,
  stockQuantity: 0,
  availability: '',
  image: null
})

// Form data constants for future use
// const categories = [
//   { value: "Laptop", label: "Laptop" },
//   { value: "Phone", label: "Phone" },
//   { value: "Watch", label: "Watch" },
//   { value: "Electronics", label: "Electronics" },
//   { value: "Accessories", label: "Accessories" },
// ]

// const brands = [
//   { value: "1", label: "Apple" },
//   { value: "2", label: "Samsung" },
//   { value: "3", label: "LG" },
// ]

// const availability = [
//   { value: "1", label: "In Stock" },
//   { value: "2", label: "Out of Stock" },
// ]

// const colors = [
//   { value: "1", label: "Silver" },
//   { value: "2", label: "Black" },
//   { value: "3", label: "White" },
//   { value: "4", label: "Gray" },
// ]

const incrementStock = () => {
  form.value.stockQuantity = form.value.stockQuantity + 1
}

const decrementStock = () => {
  if (form.value.stockQuantity > 0) {
    form.value.stockQuantity = form.value.stockQuantity - 1
  }
}

const handleFileUpload = (event: Event) => {
  const target = event.target as HTMLInputElement
  if (target.files && target.files[0]) {
    form.value.image = target.files[0]
    console.log('File uploaded:', target.files[0])
  }
}

// const handleSelectChange = (value: string) => {
//   console.log("Selected value:", value)
// }

const handleSubmit = () => {
  console.log('Product form submitted:', form.value)
  // Here you would typically send the data to your API
}
</script>
