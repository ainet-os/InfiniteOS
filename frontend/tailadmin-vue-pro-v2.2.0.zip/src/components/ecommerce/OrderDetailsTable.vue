<template>
  <div class="rounded-2xl border border-gray-200 bg-white p-6 dark:border-gray-800 dark:bg-white/3">
    <h2 class="mb-5 text-lg font-semibold text-gray-800 dark:text-white/90">
      Order Details
    </h2>
    <div class="overflow-hidden rounded-2xl border border-gray-100 dark:border-gray-800">
      <div class="custom-scrollbar overflow-x-auto">
        <table class="min-w-full text-left text-sm text-gray-700 dark:border-gray-800">
          <thead class="bg-gray-50 dark:bg-gray-900">
            <tr class="border-b border-gray-100 whitespace-nowrap dark:border-gray-800">
              <th class="px-5 py-4 text-sm font-medium whitespace-nowrap text-gray-700 dark:text-gray-400">
                S. No.
              </th>
              <th class="px-5 py-4 text-sm font-medium whitespace-nowrap text-gray-500 dark:text-gray-400">
                Products
              </th>
              <th class="px-5 py-4 text-sm font-medium whitespace-nowrap text-gray-700 dark:text-gray-400">
                Quantity
              </th>
              <th class="px-5 py-4 text-sm font-medium whitespace-nowrap text-gray-700 dark:text-gray-400">
                Unit Cost
              </th>
              <th class="px-5 py-4 text-sm font-medium whitespace-nowrap text-gray-700 dark:text-gray-400">
                Discount
              </th>
              <th class="px-5 py-4 text-sm font-medium whitespace-nowrap text-gray-700 dark:text-gray-400">
                Total
              </th>
            </tr>
          </thead>
          <tbody class="divide-y divide-gray-100 bg-white dark:divide-gray-800 dark:bg-white/[0.03]">
            <tr>
              <td class="px-5 py-4 text-sm whitespace-nowrap text-gray-500 dark:text-gray-400">
                1
              </td>
              <td class="px-5 py-4 text-sm font-medium whitespace-nowrap text-gray-800 dark:text-white/90">
                Macbook pro 13"
              </td>
              <td class="px-5 py-4 text-sm whitespace-nowrap text-gray-500 dark:text-gray-400">
                1
              </td>
              <td class="px-5 py-4 text-sm whitespace-nowrap text-gray-500 dark:text-gray-400">
                $1200
              </td>
              <td class="px-5 py-4 text-sm whitespace-nowrap text-gray-500 dark:text-gray-400">
                0%
              </td>
              <td class="px-5 py-4 text-sm whitespace-nowrap text-gray-500 dark:text-gray-400">
                $1200
              </td>
            </tr>
            <tr>
              <td class="px-5 py-4 text-sm whitespace-nowrap text-gray-500 dark:text-gray-400">
                2
              </td>
              <td class="px-5 py-4 text-sm font-medium whitespace-nowrap text-gray-800 dark:text-white/90">
                Apple Watch Ultra
              </td>
              <td class="px-5 py-4 text-sm whitespace-nowrap text-gray-500 dark:text-gray-400">
                1
              </td>
              <td class="px-5 py-4 text-sm whitespace-nowrap text-gray-500 dark:text-gray-400">
                $300
              </td>
              <td class="px-5 py-4 text-sm whitespace-nowrap text-gray-500 dark:text-gray-400">
                50%
              </td>
              <td class="px-5 py-4 text-sm whitespace-nowrap text-gray-500 dark:text-gray-400">
                $150
              </td>
            </tr>
            <tr>
              <td class="px-5 py-4 text-sm whitespace-nowrap text-gray-500 dark:text-gray-400">
                3
              </td>
              <td class="px-5 py-4 text-sm font-medium whitespace-nowrap text-gray-800 dark:text-white/90">
                iPhone 15 Pro Max
              </td>
              <td class="px-5 py-4 text-sm whitespace-nowrap text-gray-500 dark:text-gray-400">
                2
              </td>
              <td class="px-5 py-4 text-sm whitespace-nowrap text-gray-500 dark:text-gray-400">
                $800
              </td>
              <td class="px-5 py-4 text-sm whitespace-nowrap text-gray-500 dark:text-gray-400">
                0%
              </td>
              <td class="px-5 py-4 text-sm whitespace-nowrap text-gray-500 dark:text-gray-400">
                $1600
              </td>
            </tr>
            <tr>
              <td class="px-5 py-4 text-sm whitespace-nowrap text-gray-500 dark:text-gray-400">
                4
              </td>
              <td class="px-5 py-4 text-sm font-medium whitespace-nowrap text-gray-800 dark:text-white/90">
                iPad Pro 3rd Gen
              </td>
              <td class="px-5 py-4 text-sm whitespace-nowrap text-gray-500 dark:text-gray-400">
                1
              </td>
              <td class="px-5 py-4 text-sm whitespace-nowrap text-gray-500 dark:text-gray-400">
                $900
              </td>
              <td class="px-5 py-4 text-sm whitespace-nowrap text-gray-500 dark:text-gray-400">
                0%
              </td>
              <td class="px-5 py-4 text-sm whitespace-nowrap text-gray-500 dark:text-gray-400">
                $900
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    <div class="flex flex-wrap justify-between sm:justify-end">
      <div class="mt-6 w-full space-y-1 text-right sm:w-[220px]">
        <p class="mb-4 text-left text-sm font-medium text-gray-800 dark:text-white/90">
          Order summary
        </p>
        <ul class="space-y-2">
          <li class="flex justify-between gap-5">
            <span class="text-sm text-gray-500 dark:text-gray-400">
              Sub Total
            </span>
            <span class="text-sm font-medium text-gray-700 dark:text-gray-400">
              $3,850
            </span>
          </li>
          <li class="flex items-center justify-between">
            <span class="text-sm text-gray-500 dark:text-gray-400">
              Vat (10%):
            </span>
            <span class="text-sm font-medium text-gray-700 dark:text-gray-400">
              $385
            </span>
          </li>
          <li class="flex items-center justify-between">
            <span class="font-medium text-gray-700 dark:text-gray-400">
              Total
            </span>
            <span class="text-lg font-semibold text-gray-800 dark:text-white/90">
              $4,235
            </span>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
// This component uses static data to match the Next.js version exactly
</script>
