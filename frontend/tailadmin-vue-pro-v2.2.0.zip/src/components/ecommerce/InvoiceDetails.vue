<template>
  <div class="space-y-6">
    <div class="rounded-2xl border border-gray-200 bg-white p-6 dark:border-gray-800 dark:bg-white/[0.03]">
      <h3 class="mb-6 text-lg font-semibold text-gray-800 dark:text-white">
        Invoice Details
      </h3>
      <div class="text-center py-12">
        <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
        </svg>
        <h3 class="mt-4 text-lg font-medium text-gray-800 dark:text-white">Invoice Details</h3>
        <p class="mt-2 text-gray-600 dark:text-gray-400">
          Single invoice view will be implemented here
        </p>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
// Component will be implemented based on requirements
</script>
