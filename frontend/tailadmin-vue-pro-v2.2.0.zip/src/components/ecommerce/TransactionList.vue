<template>
  <div class="rounded-2xl border border-gray-200 bg-white p-6 dark:border-gray-800 dark:bg-white/[0.03]">
    <h3 class="mb-6 text-lg font-semibold text-gray-800 dark:text-white">
      Transactions
    </h3>

    <div class="overflow-x-auto">
      <table class="w-full table-auto">
        <thead>
          <tr class="border-b border-gray-200 text-left dark:border-gray-800">
            <th class="py-3 font-medium text-gray-600 dark:text-gray-400">Transaction ID</th>
            <th class="py-3 font-medium text-gray-600 dark:text-gray-400">Customer</th>
            <th class="py-3 font-medium text-gray-600 dark:text-gray-400">Date</th>
            <th class="py-3 font-medium text-gray-600 dark:text-gray-400">Amount</th>
            <th class="py-3 font-medium text-gray-600 dark:text-gray-400">Status</th>
            <th class="py-3 font-medium text-gray-600 dark:text-gray-400">Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr
            v-for="transaction in transactions"
            :key="transaction.id"
            class="border-b border-gray-200 transition-colors hover:bg-gray-50 dark:border-gray-800 dark:hover:bg-gray-800/50"
          >
            <td class="py-4 font-medium text-gray-800 dark:text-white">
              {{ transaction.id }}
            </td>
            <td class="py-4 text-gray-600 dark:text-gray-400">
              {{ transaction.customer }}
            </td>
            <td class="py-4 text-gray-600 dark:text-gray-400">
              {{ transaction.date }}
            </td>
            <td class="py-4 font-medium text-gray-800 dark:text-white">
              {{ transaction.amount }}
            </td>
            <td class="py-4">
              <span
                :class="[
                  'inline-flex rounded-full px-2 py-1 text-xs font-medium',
                  transaction.status === 'Completed'
                    ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400'
                    : transaction.status === 'Processing'
                    ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400'
                    : 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400'
                ]"
              >
                {{ transaction.status }}
              </span>
            </td>
            <td class="py-4">
              <router-link
                :to="`/single-transaction/${transaction.id}`"
                class="text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300"
              >
                View
              </router-link>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'

interface Transaction {
  id: string
  customer: string
  date: string
  amount: string
  status: 'Completed' | 'Processing' | 'Failed'
}

const transactions = ref<Transaction[]>([
  { id: 'TXN-001', customer: 'John Doe', date: 'Feb 15, 2024', amount: '$1,250.00', status: 'Completed' },
  { id: 'TXN-002', customer: 'Jane Smith', date: 'Feb 14, 2024', amount: '$890.00', status: 'Processing' },
  { id: 'TXN-003', customer: 'Bob Johnson', date: 'Feb 13, 2024', amount: '$2,100.00', status: 'Completed' },
  { id: 'TXN-004', customer: 'Alice Brown', date: 'Feb 12, 2024', amount: '$750.00', status: 'Failed' },
])
</script>
