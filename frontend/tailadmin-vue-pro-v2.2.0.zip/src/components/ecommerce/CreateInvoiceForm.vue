<template>
  <div class="rounded-2xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-white/[0.03]">
    <div class="border-b border-gray-200 px-6 py-4 dark:border-gray-800">
      <h2 class="text-xl font-medium text-gray-800 dark:text-white">
        Create Invoice
      </h2>
    </div>
    <div class="border-b border-gray-200 p-4 sm:p-8 dark:border-gray-800">
      <form class="space-y-6">
        <div class="grid grid-cols-1 gap-5 md:grid-cols-2">
          <div>
            <Label>Invoice Number</Label>
            <InputField v-model="invoiceNumber" placeholder="WP-3434434" />
          </div>
          <div>
            <Label>Customer Name</Label>
            <InputField v-model="customerName" placeholder="John Deniyal" />
          </div>
          <div class="col-span-full">
            <Label>Customer Address</Label>
            <InputField v-model="customerAddress" placeholder="Enter customer address" />
          </div>
          <div>
            <Label>Payment Condition</Label>
            <Select
              v-model="paymentCondition"
              placeholder="Select Payment Condition"
              :options="paymentConditionOptions"
            />
          </div>
          <div>
            <Label>Currency</Label>
            <Select
              v-model="currency"
              placeholder="Select Currency"
              :options="currencyOptions"
            />
          </div>
          <div>
            <Label>Issue Date</Label>
            <DatePicker v-model="issueDate" placeholder="年/月/日" />
          </div>
          <div>
            <Label>Due Date</Label>
            <DatePicker v-model="dueDate" placeholder="年/月/日" />
          </div>
          <div class="col-span-full">
            <Label>Additional Info</Label>
            <TextArea v-model="additionalInfo" placeholder="Receipt Info (optional)" :rows="3" />
          </div>
        </div>
      </form>
    </div>
    <div class="border-b border-gray-200 p-4 sm:p-8 dark:border-gray-800">
      <CreateInvoiceTable />
    </div>
    <div class="p-4 sm:p-8">
      <div class="flex flex-col gap-3 sm:flex-row sm:justify-end">
        <InvoicePreviewModal />
        <Button variant="primary" start-icon @click="saveInvoice">
          <template #startIcon>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              viewBox="0 0 20 20"
              fill="none"
            >
              <path
                d="M13.333 16.6666V12.9166C13.333 12.2262 12.7734 11.6666 12.083 11.6666L7.91634 11.6666C7.22599 11.6666 6.66634 12.2262 6.66634 12.9166L6.66635 16.6666M9.99967 5.83325H6.66634M15.4163 16.6666H4.58301C3.89265 16.6666 3.33301 16.1069 3.33301 15.4166V4.58325C3.33301 3.8929 3.89265 3.33325 4.58301 3.33325H12.8171C13.1483 3.33325 13.4659 3.46468 13.7003 3.69869L16.2995 6.29384C16.5343 6.52832 16.6662 6.84655 16.6662 7.17841L16.6663 15.4166C16.6663 16.1069 16.1066 16.6666 15.4163 16.6666Z"
                stroke="currentColor"
                stroke-width="1.5"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
            </svg>
          </template>
          Save Invoice
        </Button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import InputField from '@/components/form/InputField.vue'
import Label from '@/components/form/Label.vue'
import Select from '@/components/form/Select.vue'
import DatePicker from '@/components/form/DatePicker.vue'
import TextArea from '@/components/form/TextArea.vue'
import CreateInvoiceTable from './CreateInvoiceTable.vue'
import InvoicePreviewModal from './InvoicePreviewModal.vue'
import Button from '@/components/ui/Button.vue'

// Form data
const invoiceNumber = ref('')
const customerName = ref('')
const customerAddress = ref('')
const paymentCondition = ref('')
const currency = ref('')
const issueDate = ref('')
const dueDate = ref('')
const additionalInfo = ref('')

// Select options
const paymentConditionOptions = [
  { value: 'net30', label: 'Net 30 Days' },
  { value: 'net60', label: 'Net 60 Days' },
  { value: 'net90', label: 'Net 90 Days' },
  { value: 'due_on_receipt', label: 'Due on Receipt' },
  { value: 'cash_on_delivery', label: 'Cash on Delivery' }
]

const currencyOptions = [
  { value: 'USD', label: 'USD - US Dollar' },
  { value: 'EUR', label: 'EUR - Euro' },
  { value: 'GBP', label: 'GBP - British Pound' },
  { value: 'JPY', label: 'JPY - Japanese Yen' },
  { value: 'CNY', label: 'CNY - Chinese Yuan' }
]

const saveInvoice = () => {
  console.log('Saving invoice:', {
    invoiceNumber: invoiceNumber.value,
    customerName: customerName.value,
    customerAddress: customerAddress.value,
    paymentCondition: paymentCondition.value,
    currency: currency.value,
    issueDate: issueDate.value,
    dueDate: dueDate.value,
    additionalInfo: additionalInfo.value
  })
  // TODO: Implement actual save functionality
}
</script>
