<template>
  <div class="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-white/[0.03]">
    <!-- Header Section -->
    <div class="flex flex-col justify-between gap-5 border-b border-gray-200 px-5 py-4 sm:flex-row sm:items-center dark:border-gray-800">
      <div>
        <h3 class="text-lg font-semibold text-gray-800 dark:text-white/90">
          Products List
        </h3>
        <p class="text-sm text-gray-500 dark:text-gray-400">
          Track your store's progress to boost your sales.
        </p>
      </div>

      <div class="flex gap-3">
        <button class="inline-flex items-center justify-center gap-2 rounded-lg border border-gray-300 px-4 py-3 text-sm font-medium text-gray-700 transition hover:bg-gray-50 dark:border-gray-700 dark:text-gray-300 dark:hover:bg-gray-800">
          Export
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="20"
            height="20"
            viewBox="0 0 20 20"
            fill="none"
          >
            <path
              d="M16.667 13.3333V15.4166C16.667 16.1069 16.1074 16.6666 15.417 16.6666H4.58295C3.89259 16.6666 3.33295 16.1069 3.33295 15.4166V13.3333M10.0013 13.3333L10.0013 3.33325M6.14547 9.47942L9.99951 13.331L13.8538 9.47942"
              stroke="currentColor"
              stroke-width="1.5"
              stroke-linecap="round"
              stroke-linejoin="round"
            />
          </svg>
        </button>
        <router-link
          to="/add-product"
          class="bg-brand-500 inline-flex items-center justify-center gap-2 rounded-lg px-4 py-3 text-sm font-medium text-white transition hover:bg-brand-600"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="20"
            height="20"
            viewBox="0 0 20 20"
            fill="none"
          >
            <path
              d="M5 10.0002H15.0006M10.0002 5V15.0006"
              stroke="currentColor"
              stroke-width="1.5"
              stroke-linecap="round"
              stroke-linejoin="round"
            />
          </svg>
          Add Product
        </router-link>
      </div>
    </div>

    <!-- Search and Filter Section -->
    <div class="border-b border-gray-200 px-5 py-4 dark:border-gray-800">
      <div class="flex gap-3 sm:justify-between">
        <div class="relative flex-1 sm:flex-auto">
          <span class="absolute top-1/2 left-4 -translate-y-1/2 text-gray-500 dark:text-gray-400">
            <svg
              class="fill-current"
              width="20"
              height="20"
              viewBox="0 0 20 20"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                fill-rule="evenodd"
                clip-rule="evenodd"
                d="M3.04199 9.37336937363C3.04199 5.87693 5.87735 3.04199 9.37533 3.04199C12.8733 3.04199 15.7087 5.87693 15.7087 9.37363C15.7087 12.8703 12.8733 15.7053 9.37533 15.7053C5.87735 15.7053 3.04199 12.8703 3.04199 9.37363ZM9.37533 1.54199C5.04926 1.54199 1.54199 5.04817 1.54199 9.37363C1.54199 13.6991 5.04926 17.2053 9.37533 17.2053C11.2676 17.2053 13.0032 16.5344 14.3572 15.4176L17.1773 18.238C17.4702 18.5309 17.945 18.5309 18.2379 18.238C18.5308 17.9451 18.5309 17.4703 18.238 17.1773L15.4182 14.3573C16.5367 13.0033 17.2087 11.2669 17.2087 9.37363C17.2087 5.04817 13.7014 1.54199 9.37533 1.54199Z"
                fill=""
              />
            </svg>
          </span>
          <input
            v-model="searchQuery"
            type="text"
            placeholder="Search..."
            class="shadow-sm focus:border-brand-300 focus:ring-brand-500/10 dark:focus:border-brand-800 h-11 w-full rounded-lg border border-gray-300 bg-transparent py-2.5 pr-4 pl-11 text-sm text-gray-800 placeholder:text-gray-400 focus:ring-3 focus:outline-none sm:w-[300px] sm:min-w-[300px] dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:placeholder:text-white/30"
          />
        </div>
        <!-- Filter Dropdown -->
        <div class="relative" ref="filterRef">
          <button
            @click="showFilter = !showFilter"
            class="shadow-theme-xs flex h-11 w-full items-center justify-center gap-2 rounded-lg border border-gray-300 bg-white px-4 py-2.5 text-sm font-medium text-gray-700 sm:w-auto sm:min-w-[100px] dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400"
          >
            Filter
            <svg
              :class="['w-4 h-4 transition-transform', showFilter ? 'rotate-180' : '']"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
            </svg>
          </button>

          <!-- Filter Dropdown Content -->
          <div
            v-if="showFilter"
            class="absolute right-0 z-50 mt-2 w-56 rounded-lg border border-gray-200 bg-white p-4 shadow-lg dark:border-gray-700 dark:bg-gray-800"
          >
            <h4 class="mb-3 text-sm font-medium text-gray-800 dark:text-white">Filter by</h4>
            <div class="space-y-3">
              <div>
                <label class="mb-2 block text-xs text-gray-600 dark:text-gray-400">Category</label>
                <select
                  v-model="filters.category"
                  class="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                >
                  <option value="">All Categories</option>
                  <option value="Laptop">Laptop</option>
                  <option value="Phone">Phone</option>
                  <option value="Watch">Watch</option>
                  <option value="Electronics">Electronics</option>
                </select>
              </div>
              <div>
                <label class="mb-2 block text-xs text-gray-600 dark:text-gray-400">Brand</label>
                <select
                  v-model="filters.brand"
                  class="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                >
                  <option value="">All Brands</option>
                  <option value="Apple">Apple</option>
                  <option value="Samsung">Samsung</option>
                  <option value="Sony">Sony</option>
                </select>
              </div>
              <div>
                <label class="mb-2 block text-xs text-gray-600 dark:text-gray-400">Stock Status</label>
                <select
                  v-model="filters.stock"
                  class="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                >
                  <option value="">All Status</option>
                  <option value="In Stock">In Stock</option>
                  <option value="Out of Stock">Out of Stock</option>
                </select>
              </div>
              <div class="flex gap-2 pt-2">
                <button
                  @click="resetFilters"
                  class="flex-1 rounded-lg border border-gray-300 px-3 py-2 text-xs text-gray-600 hover:bg-gray-50 dark:border-gray-600 dark:text-gray-400 dark:hover:bg-gray-700"
                >
                  Reset
                </button>
                <button
                  @click="applyFilters"
                  class="flex-1 rounded-lg bg-blue-600 px-3 py-2 text-xs text-white hover:bg-blue-700"
                >
                  Apply
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Table -->
    <div class="overflow-x-auto custom-scrollbar">
      <table class="w-full">
        <thead>
          <tr class="border-b border-gray-200 dark:divide-gray-800 dark:border-gray-800">
            <th class="w-14 px-5 py-4 text-left">
              <label class="cursor-pointer text-sm font-medium text-gray-700 select-none dark:text-gray-400">
                <input
                  type="checkbox"
                  class="sr-only"
                  @change="toggleSelectAll"
                  :checked="isAllSelected"
                />
                <span
                  :class="[
                    'flex h-4 w-4 items-center justify-center rounded-sm border-[1.25px]',
                    isAllSelected
                      ? 'border-brand-500 bg-brand-500'
                      : 'bg-transparent border-gray-300 dark:border-gray-700'
                  ]"
                >
                  <span :class="isAllSelected ? '' : 'opacity-0'">
                    <svg
                      width="12"
                      height="12"
                      viewBox="0 0 12 12"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M10 3L4.5 8.5L2 6"
                        stroke="white"
                        stroke-width="1.6666"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                      />
                    </svg>
                  </span>
                </span>
              </label>
            </th>
            <th
              @click="sortBy('name')"
              class="cursor-pointer px-5 py-4 text-left text-xs font-medium text-gray-500 dark:text-gray-400"
            >
              <div class="flex items-center gap-3">
                <p class="text-xs font-medium text-gray-500 dark:text-gray-400">
                  Products
                </p>
                <span class="flex flex-col gap-0.5">
                  <svg
                    :class="[
                      sort.key === 'name' && sort.asc
                        ? 'text-gray-500 dark:text-gray-400'
                        : 'text-gray-300 dark:text-gray-400/50'
                    ]"
                    width="8"
                    height="5"
                    viewBox="0 0 8 5"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M4.40962 0.585167C4.21057 0.300808 3.78943 0.300807 3.59038 0.585166L1.05071 4.21327C0.81874 4.54466 1.05582 5 1.46033 5H6.53967C6.94418 5 7.18126 4.54466 6.94929 4.21327L4.40962 0.585167Z"
                      fill="currentColor"
                    />
                  </svg>
                  <svg
                    :class="[
                      sort.key === 'name' && !sort.asc
                        ? 'text-gray-500 dark:text-gray-400'
                        : 'text-gray-300 dark:text-gray-400/50'
                    ]"
                    width="8"
                    height="5"
                    viewBox="0 0 8 5"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M4.40962 4.41483C4.21057 4.69919 3.78943 4.69919 3.59038 4.41483L1.05071 0.786732C0.81874 0.455343 1.05582 0 1.46033 0H6.53967C6.94418 0 7.18126 0.455342 6.94929 0.786731L4.40962 4.41483Z"
                      fill="currentColor"
                    />
                  </svg>
                </span>
              </div>
            </th>
            <th
              @click="sortBy('category')"
              class="cursor-pointer px-5 py-4 text-left text-xs font-medium text-gray-500 dark:text-gray-400"
            >
              <div class="flex items-center gap-3">
                <p class="text-xs font-medium text-gray-500 dark:text-gray-400">
                  Category
                </p>
                <span class="flex flex-col gap-0.5">
                  <svg
                    :class="[
                      sort.key === 'category' && sort.asc
                        ? 'text-gray-500 dark:text-gray-400'
                        : 'text-gray-300 dark:text-gray-400/50'
                    ]"
                    width="8"
                    height="5"
                    viewBox="0 0 8 5"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M4.40962 0.585167C4.21057 0.300808 3.78943 0.300807 3.59038 0.585166L1.05071 4.21327C0.81874 4.54466 1.05582 5 1.46033 5H6.53967C6.94418 5 7.18126 4.54466 6.94929 4.21327L4.40962 0.585167Z"
                      fill="currentColor"
                    />
                  </svg>
                  <svg
                    :class="[
                      sort.key === 'category' && !sort.asc
                        ? 'text-gray-500 dark:text-gray-400'
                        : 'text-gray-300 dark:text-gray-400/50'
                    ]"
                    width="8"
                    height="5"
                    viewBox="0 0 8 5"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M4.40962 4.41483C4.21057 4.69919 3.78943 4.69919 3.59038 4.41483L1.05071 0.786732C0.81874 0.455343 1.05582 0 1.46033 0H6.53967C6.94418 0 7.18126 0.455342 6.94929 0.786731L4.40962 4.41483Z"
                      fill="currentColor"
                    />
                  </svg>
                </span>
              </div>
            </th>
            <th
              @click="sortBy('brand')"
              class="cursor-pointer px-5 py-4 text-left text-xs font-medium text-gray-500 dark:text-gray-400"
            >
              <div class="flex items-center gap-3">
                <p class="text-xs font-medium text-gray-500 dark:text-gray-400">
                  Brand
                </p>
                <span class="flex flex-col gap-0.5">
                  <svg
                    :class="[
                      sort.key === 'brand' && sort.asc
                        ? 'text-gray-500 dark:text-gray-400'
                        : 'text-gray-300 dark:text-gray-400/50'
                    ]"
                    width="8"
                    height="5"
                    viewBox="0 0 8 5"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M4.40962 0.585167C4.21057 0.300808 3.78943 0.300807 3.59038 0.585166L1.05071 4.21327C0.81874 4.54466 1.05582 5 1.46033 5H6.53967C6.94418 5 7.18126 4.54466 6.94929 4.21327L4.40962 0.585167Z"
                      fill="currentColor"
                    />
                  </svg>
                  <svg
                    :class="[
                      sort.key === 'brand' && !sort.asc
                        ? 'text-gray-500 dark:text-gray-400'
                        : 'text-gray-300 dark:text-gray-400/50'
                    ]"
                    width="8"
                    height="5"
                    viewBox="0 0 8 5"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M4.40962 4.41483C4.21057 4.69919 3.78943 4.69919 3.59038 4.41483L1.05071 0.786732C0.81874 0.455343 1.05582 0 1.46033 0H6.53967C6.94418 0 7.18126 0.455342 6.94929 0.786731L4.40962 4.41483Z"
                      fill="currentColor"
                    />
                  </svg>
                </span>
              </div>
            </th>
            <th
              @click="sortBy('price')"
              class="cursor-pointer px-5 py-4 text-left text-xs font-medium text-gray-500 dark:text-gray-400"
            >
              <div class="flex items-center gap-3">
                <p class="text-xs font-medium text-gray-500 dark:text-gray-400">
                  Price
                </p>
                <span class="flex flex-col gap-0.5">
                  <svg
                    :class="[
                      sort.key === 'price' && sort.asc
                        ? 'text-gray-500 dark:text-gray-400'
                        : 'text-gray-300 dark:text-gray-400/50'
                    ]"
                    width="8"
                    height="5"
                    viewBox="0 0 8 5"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M4.40962 0.585167C4.21057 0.300808 3.78943 0.300807 3.59038 0.585166L1.05071 4.21327C0.81874 4.54466 1.05582 5 1.46033 5H6.53967C6.94418 5 7.18126 4.54466 6.94929 4.21327L4.40962 0.585167Z"
                      fill="currentColor"
                    />
                  </svg>
                  <svg
                    :class="[
                      sort.key === 'price' && !sort.asc
                        ? 'text-gray-500 dark:text-gray-400'
                        : 'text-gray-300 dark:text-gray-400/50'
                    ]"
                    width="8"
                    height="5"
                    viewBox="0 0 8 5"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M4.40962 4.41483C4.21057 4.69919 3.78943 4.69919 3.59038 4.41483L1.05071 0.786732C0.81874 0.455343 1.05582 0 1.46033 0H6.53967C6.94418 0 7.18126 0.455342 6.94929 0.786731L4.40962 4.41483Z"
                      fill="currentColor"
                    />
                  </svg>
                </span>
              </div>
            </th>
            <th class="px-5 py-4 text-left text-xs font-medium text-gray-500 dark:text-gray-400">
              Stock
            </th>
            <th class="px-5 py-4 text-left text-xs font-medium text-gray-500 dark:text-gray-400">
              Created At
            </th>
            <th class="px-5 py-4 text-left text-xs font-medium text-gray-500 dark:text-gray-400">
              Actions
            </th>
          </tr>
        </thead>
        <tbody>
          <tr
            v-for="product in paginatedProducts"
            :key="product.id"
            class="border-b border-gray-200 transition-colors hover:bg-gray-50 dark:border-gray-800 dark:hover:bg-gray-800/50"
          >
            <td class="px-5 py-4">
              <label class="cursor-pointer text-sm font-medium text-gray-700 select-none dark:text-gray-400">
                <input
                  type="checkbox"
                  class="sr-only"
                  :checked="selectedProducts.includes(product.id)"
                  @change="toggleProduct(product.id)"
                />
                <span
                  :class="[
                    'flex h-4 w-4 items-center justify-center rounded-sm border-[1.25px]',
                    selectedProducts.includes(product.id)
                      ? 'border-brand-500 bg-brand-500'
                      : 'bg-transparent border-gray-300 dark:border-gray-700'
                  ]"
                >
                  <span :class="selectedProducts.includes(product.id) ? '' : 'opacity-0'">
                    <svg
                      width="12"
                      height="12"
                      viewBox="0 0 12 12"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M10 3L4.5 8.5L2 6"
                        stroke="white"
                        stroke-width="1.6666"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                      />
                    </svg>
                  </span>
                </span>
              </label>
            </td>
            <td class="px-5 py-4">
              <div class="flex items-center gap-3">
                <img
                  :src="product.image"
                  :alt="product.name"
                  class="h-12 w-12 rounded-lg object-cover"
                />
                <div>
                  <h4 class="font-medium text-gray-800 dark:text-white/90">
                    {{ product.name }}
                  </h4>
                </div>
              </div>
            </td>
            <td class="px-5 py-4 text-gray-600 dark:text-gray-400">
              {{ product.category }}
            </td>
            <td class="px-5 py-4 text-gray-600 dark:text-gray-400">
              {{ product.brand }}
            </td>
            <td class="px-5 py-4 font-medium text-gray-800 dark:text-white/90">
              {{ product.price }}
            </td>
            <td class="px-5 py-4">
              <span
                :class="[
                  'inline-flex rounded-full px-2 py-1 text-xs font-medium',
                  product.stock === 'In Stock'
                    ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400'
                    : 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400'
                ]"
              >
                {{ product.stock }}
              </span>
            </td>
            <td class="px-5 py-4 text-gray-600 dark:text-gray-400">
              {{ product.createdAt }}
            </td>
            <td class="px-5 py-4">
              <div class="flex items-center gap-2">
                <button
                  class="inline-flex h-8 w-8 items-center justify-center rounded-lg text-gray-500 transition hover:bg-gray-100 hover:text-gray-700 dark:text-gray-400 dark:hover:bg-gray-800 dark:hover:text-gray-300"
                >
                  <svg
                    width="16"
                    height="16"
                    viewBox="0 0 16 16"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M2.66675 8.66668C2.66675 8.66668 5.33341 3.33334 8.00008 3.33334C10.6667 3.33334 13.3334 8.66668 13.3334 8.66668C13.3334 8.66668 10.6667 14 8.00008 14C5.33341 14 2.66675 8.66668 2.66675 8.66668Z"
                      stroke="currentColor"
                      stroke-width="1.33333"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    />
                    <path
                      d="M8 10.6667C9.10457 10.6667 10 9.77124 10 8.66667C10 7.5621 9.10457 6.66667 8 6.66667C6.89543 6.66667 6 7.5621 6 8.66667C6 9.77124 6.89543 10.6667 8 10.6667Z"
                      stroke="currentColor"
                      stroke-width="1.33333"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    />
                  </svg>
                </button>
                <button
                  class="inline-flex h-8 w-8 items-center justify-center rounded-lg text-gray-500 transition hover:bg-gray-100 hover:text-gray-700 dark:text-gray-400 dark:hover:bg-gray-800 dark:hover:text-gray-300"
                >
                  <svg
                    width="16"
                    height="16"
                    viewBox="0 0 16 16"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M2.66675 4.00001H13.3334M8.00008 1.33334V4.00001M6.66675 7.33334V11.3333M9.33341 7.33334V11.3333M3.33341 4.00001L4.00008 13.3333C4.00008 14.0697 4.59708 14.6667 5.33341 14.6667H10.6667C11.4031 14.6667 12.0001 14.0697 12.0001 13.3333L12.6667 4.00001"
                      stroke="currentColor"
                      stroke-width="1.33333"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    />
                  </svg>
                </button>
                <button
                  class="inline-flex h-8 w-8 items-center justify-center rounded-lg text-gray-500 transition hover:bg-gray-100 hover:text-gray-700 dark:text-gray-400 dark:hover:bg-gray-800 dark:hover:text-gray-300"
                >
                  <svg
                    width="16"
                    height="16"
                    viewBox="0 0 16 16"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M8 1.33334V8.00001M8 8.00001V14.6667M8 8.00001H14.6667M8 8.00001H1.33333"
                      stroke="currentColor"
                      stroke-width="1.33333"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    />
                  </svg>
                </button>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- Pagination -->
    <div class="flex items-center justify-between border-t border-gray-200 px-5 py-4 dark:border-gray-800">
      <div class="flex items-center text-sm text-gray-600 dark:text-gray-400">
        <span>Showing {{ startItem }} to {{ endItem }} of {{ products.length }} entries</span>
      </div>
      <div class="flex items-center gap-1">
        <button
          @click="prevPage"
          :disabled="currentPage === 1"
          class="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-gray-300 text-gray-500 transition hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-800"
        >
          <svg
            width="16"
            height="16"
            viewBox="0 0 16 16"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M10 12L6 8L10 4"
              stroke="currentColor"
              stroke-width="1.33333"
              stroke-linecap="round"
              stroke-linejoin="round"
            />
          </svg>
        </button>
        <button
          v-for="page in visiblePages"
          :key="page"
          @click="goToPage(page)"
          :class="[
            'inline-flex h-8 w-8 items-center justify-center rounded-lg text-sm transition',
            page === currentPage
              ? 'bg-brand-500 text-white'
              : 'border border-gray-300 text-gray-500 hover:bg-gray-50 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-800'
          ]"
        >
          {{ page }}
        </button>
        <button
          @click="nextPage"
          :disabled="currentPage === totalPages"
          class="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-gray-300 text-gray-500 transition hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-800"
        >
          <svg
            width="16"
            height="16"
            viewBox="0 0 16 16"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M6 4L10 8L6 12"
              stroke="currentColor"
              stroke-width="1.33333"
              stroke-linecap="round"
              stroke-linejoin="round"
            />
          </svg>
        </button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted } from 'vue'

interface Product {
  id: number
  name: string
  image: string
  category: string
  brand: string
  price: string
  stock: string
  createdAt: string
}

interface Sort {
  key: keyof Product
  asc: boolean
}

interface Filters {
  category: string
  brand: string
  stock: string
}

const searchQuery = ref('')
const selectedProducts = ref<number[]>([])
const currentPage = ref(1)
const perPage = 7
const showFilter = ref(false)
const filterRef = ref<HTMLElement | null>(null)

const sort = ref<Sort>({ key: 'name', asc: true })
const filters = ref<Filters>({
  category: '',
  brand: '',
  stock: ''
})

// Sample product data - expanded to match Next.js version
const products = ref<Product[]>([
  {
    id: 1,
    name: "MacBook Pro 14 inch",
    image: "/images/product/product-01.jpg",
    category: "Laptop",
    brand: "Apple",
    price: "$699",
    stock: "In Stock",
    createdAt: "12 Feb, 2027",
  },
  {
    id: 2,
    name: "Apple Watch Ultra",
    image: "/images/product/product-02.jpg",
    category: "Watch",
    brand: "Apple",
    price: "$1,579",
    stock: "Out of Stock",
    createdAt: "13 Mar, 2027",
  },
  {
    id: 3,
    name: "iPhone 15 Pro Max",
    image: "/images/product/product-03.jpg",
    category: "Phone",
    brand: "Apple",
    price: "$1,039",
    stock: "In Stock",
    createdAt: "19 Mar, 2027",
  },
  {
    id: 4,
    name: "iPad Pro 3rd Gen",
    image: "/images/product/product-04.jpg",
    category: "Electronics",
    brand: "Apple",
    price: "$43,999",
    stock: "In Stock",
    createdAt: "25 Apr, 2027",
  },
  {
    id: 5,
    name: "Samsung Galaxy S24 Ultra",
    image: "/images/product/product-05.jpg",
    category: "Phone",
    brand: "Samsung",
    price: "$699",
    stock: "In Stock",
    createdAt: "11 May, 2027",
  },
  {
    id: 6,
    name: "Airpods Pro 2nd Gen",
    image: "/images/product/product-01.jpg",
    category: "Accessories",
    brand: "Apple",
    price: "$839",
    stock: "In Stock",
    createdAt: "29 Jun, 2027",
  },
  {
    id: 7,
    name: "LG OLED & 4K Smart TV",
    image: "/images/product/product-02.jpg",
    category: "Electronics",
    brand: "LG",
    price: "$1,769",
    stock: "Out of Stock",
    createdAt: "22 Jul, 2027",
  },
  {
    id: 8,
    name: "Sony WH-1000XM5 Headphones",
    image: "/images/product/product-03.jpg",
    category: "Audio",
    brand: "Sony",
    price: "$399",
    stock: "In Stock",
    createdAt: "05 Aug, 2027",
  },
  {
    id: 9,
    name: "Dell XPS 13 Laptop",
    image: "/images/product/product-04.jpg",
    category: "Laptop",
    brand: "Dell",
    price: "$1,299",
    stock: "In Stock",
    createdAt: "18 Aug, 2027",
  },
  {
    id: 10,
    name: "Google Pixel 8 Pro",
    image: "/images/product/product-05.jpg",
    category: "Phone",
    brand: "Google",
    price: "$899",
    stock: "Out of Stock",
    createdAt: "02 Sep, 2027",
  },
])

const sortedProducts = computed(() => {
  return [...products.value].sort((a, b) => {
    let valA = a[sort.value.key]
    let valB = b[sort.value.key]

    if (sort.value.key === 'price') {
      valA = parseFloat(String(valA).replace(/[^\d.]/g, ''))
      valB = parseFloat(String(valB).replace(/[^\d.]/g, ''))
    }

    if (valA < valB) return sort.value.asc ? -1 : 1
    if (valA > valB) return sort.value.asc ? 1 : -1
    return 0
  })
})

const paginatedProducts = computed(() => {
  const start = (currentPage.value - 1) * perPage
  return sortedProducts.value.slice(start, start + perPage)
})

const totalPages = computed(() => Math.ceil(products.value.length / perPage))

const startItem = computed(() => {
  return products.value.length === 0 ? 0 : (currentPage.value - 1) * perPage + 1
})

const endItem = computed(() => {
  return Math.min(currentPage.value * perPage, products.value.length)
})

const visiblePages = computed(() => {
  const pages = []
  const maxVisible = 5
  const halfVisible = Math.floor(maxVisible / 2)

  let start = Math.max(1, currentPage.value - halfVisible)
  let end = Math.min(totalPages.value, start + maxVisible - 1)

  if (end - start + 1 < maxVisible) {
    start = Math.max(1, end - maxVisible + 1)
  }

  for (let i = start; i <= end; i++) {
    pages.push(i)
  }

  return pages
})

const isAllSelected = computed(() => {
  const ids = paginatedProducts.value.map(p => p.id)
  return ids.length > 0 && ids.every(id => selectedProducts.value.includes(id))
})

const goToPage = (n: number) => {
  if (n >= 1 && n <= totalPages.value) {
    currentPage.value = n
  }
}

const prevPage = () => {
  if (currentPage.value > 1) {
    currentPage.value = currentPage.value - 1
  }
}

const nextPage = () => {
  if (currentPage.value < totalPages.value) {
    currentPage.value = currentPage.value + 1
  }
}

const toggleSelectAll = () => {
  const ids = paginatedProducts.value.map(p => p.id)
  if (isAllSelected.value) {
    selectedProducts.value = selectedProducts.value.filter(id => !ids.includes(id))
  } else {
    selectedProducts.value = [...new Set([...selectedProducts.value, ...ids])]
  }
}

const toggleProduct = (productId: number) => {
  const index = selectedProducts.value.indexOf(productId)
  if (index > -1) {
    selectedProducts.value.splice(index, 1)
  } else {
    selectedProducts.value.push(productId)
  }
}

const sortBy = (key: keyof Product) => {
  sort.value = {
    key,
    asc: sort.value.key === key ? !sort.value.asc : true
  }
}

const resetFilters = () => {
  filters.value = {
    category: '',
    brand: '',
    stock: ''
  }
}

const applyFilters = () => {
  // Apply filter logic here if needed
  showFilter.value = false
}

// Close filter dropdown when clicking outside
const handleClickOutside = (event: MouseEvent) => {
  if (filterRef.value && !filterRef.value.contains(event.target as Node)) {
    showFilter.value = false
  }
}

onMounted(() => {
  document.addEventListener('click', handleClickOutside)
})

onUnmounted(() => {
  document.removeEventListener('click', handleClickOutside)
})
</script>

