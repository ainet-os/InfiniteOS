<template>
  <div class="flex flex-col justify-between gap-6 rounded-2xl border border-gray-200 bg-white px-6 py-5 sm:flex-row sm:items-center dark:border-gray-800 dark:bg-white/3">
    <div class="flex flex-col gap-2.5 divide-gray-300 sm:flex-row sm:divide-x dark:divide-gray-700">
      <div class="flex items-center gap-2 sm:pr-3">
        <span class="text-base font-medium text-gray-700 dark:text-gray-400">
          Order ID : #{{ transactionData.orderId }}
        </span>
        <span :class="getStatusClass(transactionData.status)">
          {{ transactionData.status }}
        </span>
      </div>
      <p class="text-sm text-gray-500 sm:pl-3 dark:text-gray-400">
        Due date: {{ transactionData.dueDate }}
      </p>
    </div>
    <div class="flex gap-3">
      <button
        @click="viewReceipt"
        class="bg-brand-500 shadow-theme-xs hover:bg-brand-600 inline-flex items-center justify-center gap-2 rounded-lg px-4 py-3 text-sm font-medium text-white transition"
      >
        View Receipt
      </button>
      <button
        @click="processRefund"
        class="shadow-theme-xs inline-flex items-center justify-center gap-2 rounded-lg bg-white px-4 py-3 text-sm font-medium text-gray-700 ring-1 ring-gray-300 transition hover:bg-gray-50 dark:bg-gray-800 dark:text-gray-400 dark:ring-gray-700 dark:hover:bg-white/[0.03]"
      >
        Refund
      </button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { useRoute } from 'vue-router'

const route = useRoute()

const transactionData = ref({
  orderId: '34834',
  status: 'Completed',
  dueDate: '25 August 2025'
})

const getStatusClass = (status: string) => {
  if (status === 'Completed') {
    return 'bg-success-50 text-success-600 dark:bg-success-500/15 dark:text-success-500 inline-flex items-center justify-center gap-1 rounded-full px-2.5 py-0.5 text-sm font-medium'
  } else if (status === 'Failed') {
    return 'bg-error-50 text-error-600 dark:bg-error-500/15 dark:text-error-500 inline-flex items-center justify-center gap-1 rounded-full px-2.5 py-0.5 text-sm font-medium'
  } else {
    return 'bg-warning-50 text-warning-600 dark:bg-warning-500/15 dark:text-warning-500 inline-flex items-center justify-center gap-1 rounded-full px-2.5 py-0.5 text-sm font-medium'
  }
}

const viewReceipt = () => {
  console.log('Viewing receipt for transaction:', transactionData.value.orderId)
  // TODO: Implement receipt viewing
}

const processRefund = () => {
  if (confirm('Are you sure you want to process a refund for this transaction?')) {
    console.log('Processing refund for transaction:', transactionData.value.orderId)
    // TODO: Implement refund processing
  }
}
</script>
