<template>
  <div class="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-white/[0.03]">
    <div class="flex items-center justify-between border-b border-gray-200 px-5 py-4 dark:border-gray-800">
      <div>
        <h3 class="text-lg font-semibold text-gray-800 dark:text-white/90">
          Transactions
        </h3>
        <p class="text-sm text-gray-500 dark:text-gray-400">
          Your most recent transactions
        </p>
      </div>
      <div class="flex gap-3.5">
        <div class="relative">
          <span class="absolute top-1/2 left-4 -translate-y-1/2 text-gray-500 dark:text-gray-400">
            <svg
              class="fill-current"
              width="20"
              height="20"
              viewBox="0 0 20 20"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                fill-rule="evenodd"
                clip-rule="evenodd"
                d="M3.04199 9.37363C3.04199 5.87693 5.87735 3.04199 9.37533 3.04199C12.8733 3.04199 15.7087 5.87693 15.7087 9.37363C15.7087 12.8703 12.8733 15.7053 9.37533 15.7053C5.87735 15.7053 3.04199 12.8703 3.04199 9.37363ZM9.37533 1.54199C5.04926 1.54199 1.54199 5.04817 1.54199 9.37363C1.54199 13.6991 5.04926 17.2053 9.37533 17.2053C11.2676 17.2053 13.0032 16.5344 14.3572 15.4176L17.1773 18.238C17.4702 18.5309 17.945 18.5309 18.2379 18.238C18.5308 17.9451 18.5309 17.4703 18.238 17.1773L15.4182 14.3573C16.5367 13.0033 17.2087 11.2669 17.2087 9.37363C17.2087 5.04817 13.7014 1.54199 9.37533 1.54199Z"
                fill=""
              />
            </svg>
          </span>
          <input
            type="text"
            placeholder="Search..."
            class="dark:bg-dark-900 shadow-theme-xs focus:border-brand-300 focus:ring-brand-500/10 dark:focus:border-brand-800 h-11 w-full rounded-lg border border-gray-300 bg-transparent py-2.5 pr-4 pl-11 text-sm text-gray-800 placeholder:text-gray-400 focus:ring-3 focus:outline-hidden xl:w-[300px] dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:placeholder:text-white/30"
            v-model="search"
          />
        </div>
        <button class="shadow-theme-xs flex w-full items-center justify-center gap-2 rounded-lg border border-gray-300 bg-white px-4 py-[11px] text-sm font-medium text-gray-700 sm:w-auto dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="20"
            height="20"
            viewBox="0 0 20 20"
            fill="none"
          >
            <path
              d="M16.6671 13.3333V15.4166C16.6671 16.1069 16.1074 16.6666 15.4171 16.6666H4.58301C3.89265 16.6666 3.33301 16.1069 3.33301 15.4166V13.3333M10.0013 3.33325L10.0013 13.3333M6.14553 7.18708L9.99958 3.33549L13.8539 7.18708"
              stroke="currentColor"
              stroke-width="1.5"
              stroke-linecap="round"
              stroke-linejoin="round"
            />
          </svg>
          Export
        </button>
      </div>
    </div>
    <div class="overflow-x-auto custom-scrollbar">
      <table class="w-full table-auto">
        <thead>
          <tr class="border-b border-gray-200 dark:divide-gray-800 dark:border-gray-800">
            <th class="p-4 text-left text-xs font-medium text-gray-700 dark:text-gray-400">
              Order ID
            </th>
            <th
              class="cursor-pointer p-4 text-left text-xs font-medium text-gray-700 dark:text-gray-400"
              @click="sortBy('customer')"
            >
              <div class="flex items-center gap-3">
                <p class="text-theme-xs font-medium text-gray-700 dark:text-gray-400">
                  Customer
                </p>
                <span class="flex flex-col gap-0.5">
                  <svg
                    :class="getSortIconClass('customer', true)"
                    width="8"
                    height="5"
                    viewBox="0 0 8 5"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M4.40962 0.585167C4.21057 0.300808 3.78943 0.300807 3.59038 0.585166L1.05071 4.21327C0.81874 4.54466 1.05582 5 1.46033 5H6.53967C6.94418 5 7.18126 4.54466 6.94929 4.21327L4.40962 0.585167Z"
                      fill="currentColor"
                    />
                  </svg>
                  <svg
                    :class="getSortIconClass('customer', false)"
                    width="8"
                    height="5"
                    viewBox="0 0 8 5"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M4.40962 4.41483C4.21057 4.69919 3.78943 4.69919 3.59038 4.41483L1.05071 0.786732C0.81874 0.455343 1.05582 0 1.46033 0H6.53967C6.94418 0 7.18126 0.455342 6.94929 0.786731L4.40962 4.41483Z"
                      fill="currentColor"
                    />
                  </svg>
                </span>
              </div>
            </th>
            <th
              class="cursor-pointer p-4 text-left text-xs font-medium text-gray-700 dark:text-gray-400"
              @click="sortBy('email')"
            >
              <div class="flex items-center gap-3">
                <p class="text-theme-xs font-medium text-gray-700 dark:text-gray-400">
                  Email
                </p>
                <span class="flex flex-col gap-0.5">
                  <svg
                    :class="getSortIconClass('email', true)"
                    width="8"
                    height="5"
                    viewBox="0 0 8 5"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M4.40962 0.585167C4.21057 0.300808 3.78943 0.300807 3.59038 0.585166L1.05071 4.21327C0.81874 4.54466 1.05582 5 1.46033 5H6.53967C6.94418 5 7.18126 4.54466 6.94929 4.21327L4.40962 0.585167Z"
                      fill="currentColor"
                    />
                  </svg>
                  <svg
                    :class="getSortIconClass('email', false)"
                    width="8"
                    height="5"
                    viewBox="0 0 8 5"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M4.40962 4.41483C4.21057 4.69919 3.78943 4.69919 3.59038 4.41483L1.05071 0.786732C0.81874 0.455343 1.05582 0 1.46033 0H6.53967C6.94418 0 7.18126 0.455342 6.94929 0.786731L4.40962 4.41483Z"
                      fill="currentColor"
                    />
                  </svg>
                </span>
              </div>
            </th>
            <th
              class="cursor-pointer p-4 text-left text-xs font-medium text-gray-700 dark:text-gray-400"
              @click="sortBy('amount')"
            >
              <div class="flex items-center gap-3">
                <p class="text-theme-xs font-medium text-gray-700 dark:text-gray-400">
                  Amount
                </p>
                <span class="flex flex-col gap-0.5">
                  <svg
                    :class="getSortIconClass('amount', true)"
                    width="8"
                    height="5"
                    viewBox="0 0 8 5"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M4.40962 0.585167C4.21057 0.300808 3.78943 0.300807 3.59038 0.585166L1.05071 4.21327C0.81874 4.54466 1.05582 5 1.46033 5H6.53967C6.94418 5 7.18126 4.54466 6.94929 4.21327L4.40962 0.585167Z"
                      fill="currentColor"
                    />
                  </svg>
                  <svg
                    :class="getSortIconClass('amount', false)"
                    width="8"
                    height="5"
                    viewBox="0 0 8 5"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M4.40962 4.41483C4.21057 4.69919 3.78943 4.69919 3.59038 4.41483L1.05071 0.786732C0.81874 0.455343 1.05582 0 1.46033 0H6.53967C6.94418 0 7.18126 0.455342 6.94929 0.786731L4.40962 4.41483Z"
                      fill="currentColor"
                    />
                  </svg>
                </span>
              </div>
            </th>
            <th class="p-4 text-left text-xs font-medium text-gray-700 dark:text-gray-400">
              Status
            </th>
            <th class="p-4 text-left text-xs font-medium text-gray-700 dark:text-gray-400">
              Due Date
            </th>
            <th class="p-4 text-left text-xs font-medium text-gray-700 dark:text-gray-400">
              <div class="relative">
                <span class="sr-only">Action</span>
              </div>
            </th>
          </tr>
        </thead>
        <tbody class="divide-x divide-y divide-gray-200 dark:divide-gray-800">
          <tr
            v-for="transaction in paginatedTransactions"
            :key="transaction.id"
            class="transition hover:bg-gray-50 dark:hover:bg-gray-900"
          >
            <td class="p-4 whitespace-nowrap">
              <router-link
                to="/single-transaction"
                class="text-theme-xs font-medium text-gray-700 hover:underline dark:text-gray-400"
              >
                {{ transaction.orderId }}
              </router-link>
            </td>
            <td class="p-4 whitespace-nowrap">
              <span class="text-sm font-medium text-gray-700 dark:text-gray-400">
                {{ transaction.customer }}
              </span>
            </td>
            <td class="p-4 whitespace-nowrap">
              <p class="text-sm text-gray-700 dark:text-gray-400">
                {{ transaction.email }}
              </p>
            </td>
            <td class="p-4 whitespace-nowrap">
              <p class="text-sm text-gray-700 dark:text-gray-400">
                {{ transaction.amountDisplay }}
              </p>
            </td>
            <td class="p-4 whitespace-nowrap">
              <span :class="getStatusClass(transaction.status)">
                {{ transaction.status }}
              </span>
            </td>
            <td class="p-4 whitespace-nowrap">
              <p class="text-sm text-gray-700 dark:text-gray-400">
                {{ transaction.dueDate }}
              </p>
            </td>
            <td class="p-4 whitespace-nowrap">
              <div class="relative flex justify-center">
                <SimpleDropdown>
                  <router-link
                    :to="`/single-transaction/${transaction.id}`"
                    class="text-xs flex w-full rounded-lg px-3 py-2 text-left font-medium text-gray-500 hover:bg-gray-100 hover:text-gray-700 dark:text-gray-400 dark:hover:bg-white/5 dark:hover:text-gray-300"
                  >
                    View Details
                  </router-link>
                  <button
                    @click="downloadReceipt(transaction.id)"
                    class="text-xs flex w-full rounded-lg px-3 py-2 text-left font-medium text-gray-500 hover:bg-gray-100 hover:text-gray-700 dark:text-gray-400 dark:hover:bg-white/5 dark:hover:text-gray-300"
                  >
                    Download Receipt
                  </button>
                  <button
                    @click="refundTransaction(transaction.id)"
                    class="text-xs flex w-full rounded-lg px-3 py-2 text-left font-medium text-orange-500 hover:bg-orange-50 hover:text-orange-700 dark:text-orange-400 dark:hover:bg-orange-500/10 dark:hover:text-orange-300"
                  >
                    Process Refund
                  </button>
                </SimpleDropdown>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    <div class="flex items-center flex-col sm:flex-row justify-between border-t border-gray-200 px-5 py-4 dark:border-gray-800">
      <div class="pb-4 sm:pb-0">
        <span class="block text-sm font-medium text-gray-500 dark:text-gray-400">
          Showing
          <span class="text-gray-800 dark:text-white/90">{{ startEntry }}</span>
          to
          <span class="text-gray-800 dark:text-white/90">{{ endEntry }}</span>
          of
          <span class="text-gray-800 dark:text-white/90">{{ sortedTransactions.length }}</span>
        </span>
      </div>
      <div class="flex items-center justify-between gap-2 bg-gray-50 p-4 sm:p-0 rounded-lg sm:bg-transparent dark:sm:bg-transparent w-full sm:w-auto dark:bg-white/[0.03] sm:justify-normal">
        <button
          :class="previousButtonClass"
          @click="previousPage"
          :disabled="currentPage === 1"
        >
          <svg
            class="fill-current"
            width="20"
            height="20"
            viewBox="0 0 20 20"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              fill-rule="evenodd"
              clip-rule="evenodd"
              d="M2.58203 9.99868C2.58174 10.1909 2.6549 10.3833 2.80152 10.53L7.79818 15.5301C8.09097 15.8231 8.56584 15.8233 8.85883 15.5305C9.15183 15.2377 9.152 14.7629 8.85921 14.4699L5.13911 10.7472L16.6665 10.7472C17.0807 10.7472 17.4165 10.4114 17.4165 9.99715C17.4165 9.58294 17.0807 9.24715 16.6665 9.24715L5.14456 9.24715L8.85919 5.53016C9.15199 5.23717 9.15184 4.7623 8.85885 4.4695C8.56587 4.1767 8.09099 4.17685 7.79819 4.46984L2.84069 9.43049C2.68224 9.568 2.58203 9.77087 2.58203 9.99715C2.58203 9.99766 2.58203 9.99817 2.58203 9.99868Z"
              fill=""
            />
          </svg>
        </button>
        <span class="block text-sm font-medium text-gray-700 sm:hidden dark:text-gray-400">
          Page {{ currentPage }} of {{ totalPages }}
        </span>
        <ul class="hidden items-center gap-0.5 sm:flex">
          <li v-for="page in visiblePages" :key="page">
            <button
              @click="goToPage(page)"
              :class="getPageButtonClass(page)"
            >
              {{ page }}
            </button>
          </li>
          <li v-if="visiblePages[visiblePages.length - 1] < totalPages">
            <span class="flex h-10 w-10 items-center justify-center rounded-lg text-sm font-medium text-gray-700 dark:text-gray-400">
              ...
            </span>
          </li>
          <li v-if="visiblePages[visiblePages.length - 1] < totalPages">
            <button
              @click="goToPage(totalPages)"
              class="hover:bg-brand-500 flex h-10 w-10 items-center justify-center rounded-lg text-sm font-medium text-gray-700 hover:text-white dark:text-gray-400 dark:hover:text-white"
            >
              {{ totalPages }}
            </button>
          </li>
        </ul>
        <button
          :class="nextButtonClass"
          @click="nextPage"
          :disabled="currentPage === totalPages"
        >
          <svg
            class="fill-current"
            width="20"
            height="20"
            viewBox="0 0 20 20"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              fill-rule="evenodd"
              clip-rule="evenodd"
              d="M17.4165 9.9986C17.4168 10.1909 17.3437 10.3832 17.197 10.53L12.2004 15.5301C11.9076 15.8231 11.4327 15.8233 11.1397 15.5305C10.8467 15.2377 10.8465 14.7629 11.1393 14.4699L14.8594 10.7472L3.33203 10.7472C2.91782 10.7472 2.58203 10.4114 2.58203 9.99715C2.58203 9.58294 2.91782 9.24715 3.33203 9.24715L14.854 9.24715L11.1393 5.53016C10.8465 5.23717 10.8467 4.7623 11.1397 4.4695C11.4327 4.1767 11.9075 4.17685 12.2003 4.46984L17.1578 9.43049C17.3163 9.568 17.4165 9.77087 17.4165 9.99715C17.4165 9.99763 17.4165 9.99812 17.4165 9.9986Z"
              fill=""
            />
          </svg>
        </button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
import { RouterLink } from 'vue-router'
import SimpleDropdown from '@/components/common/SimpleDropdown.vue'

interface Transaction {
  id: number
  orderId: string
  customer: string
  email: string
  amount: number
  amountDisplay: string
  status: "Completed" | "Pending" | "Failed"
  dueDate: string
}

interface SortState {
  key: "customer" | "email" | "amount"
  asc: boolean
}

const initialTransactions: Transaction[] = [
  {
    id: 1,
    orderId: "#323534",
    customer: "Lindsey Curtis",
    email: "lindsey@example.com",
    amount: 699,
    amountDisplay: "$699",
    status: "Completed",
    dueDate: "12 Feb, 2027",
  },
  {
    id: 2,
    orderId: "#323535",
    customer: "Kaiya George",
    email: "kaiya@example.com",
    amount: 1579,
    amountDisplay: "$1,579",
    status: "Failed",
    dueDate: "13 Mar, 2027",
  },
  {
    id: 3,
    orderId: "#323536",
    customer: "Zain Geidt",
    email: "zain787@example.com",
    amount: 1039,
    amountDisplay: "$1,039",
    status: "Pending",
    dueDate: "27 Jan, 2027",
  },
  {
    id: 4,
    orderId: "#323537",
    customer: "Maria Garcia",
    email: "maria@example.com",
    amount: 899,
    amountDisplay: "$899",
    status: "Completed",
    dueDate: "15 Apr, 2027",
  },
  {
    id: 5,
    orderId: "#323538",
    customer: "James Wilson",
    email: "james@example.com",
    amount: 1299,
    amountDisplay: "$1,299",
    status: "Pending",
    dueDate: "08 May, 2027",
  },
  {
    id: 6,
    orderId: "#323539",
    customer: "Sarah Johnson",
    email: "sarah@example.com",
    amount: 799,
    amountDisplay: "$799",
    status: "Completed",
    dueDate: "22 Jun, 2027",
  },
  {
    id: 7,
    orderId: "#323540",
    customer: "Michael Brown",
    email: "michael@example.com",
    amount: 1599,
    amountDisplay: "$1,599",
    status: "Failed",
    dueDate: "11 Jul, 2027",
  },
  {
    id: 8,
    orderId: "#323541",
    customer: "Emily Davis",
    email: "emily@example.com",
    amount: 999,
    amountDisplay: "$999",
    status: "Completed",
    dueDate: "03 Aug, 2027",
  },
  {
    id: 9,
    orderId: "#323542",
    customer: "David Miller",
    email: "david@example.com",
    amount: 1199,
    amountDisplay: "$1,199",
    status: "Pending",
    dueDate: "18 Sep, 2027",
  },
  {
    id: 10,
    orderId: "#323543",
    customer: "Lisa Thompson",
    email: "lisa@example.com",
    amount: 1399,
    amountDisplay: "$1,399",
    status: "Completed",
    dueDate: "09 Oct, 2027",
  },
]

const transactions = ref<Transaction[]>(initialTransactions)
const sort = ref<SortState>({
  key: "customer",
  asc: true,
})
const currentPage = ref<number>(1)
const search = ref<string>("")
const itemsPerPage = 10

const searchedTransactions = computed(() => {
  return transactions.value.filter(
    (transaction) =>
      transaction.orderId.toLowerCase().includes(search.value.toLowerCase()) ||
      transaction.customer.toLowerCase().includes(search.value.toLowerCase()) ||
      transaction.email.toLowerCase().includes(search.value.toLowerCase())
  )
})

const sortedTransactions = computed(() => {
  return [...searchedTransactions.value].sort((a, b) => {
    let valA: string | number = a[sort.value.key]
    let valB: string | number = b[sort.value.key]

    if (sort.value.key === "amount") {
      valA = Number(valA)
      valB = Number(valB)
    } else {
      valA = typeof valA === "string" ? valA.toLowerCase() : valA
      valB = typeof valB === "string" ? valB.toLowerCase() : valB
    }

    if (valA < valB) return sort.value.asc ? -1 : 1
    if (valA > valB) return sort.value.asc ? 1 : -1
    return 0
  })
})

const paginatedTransactions = computed(() => {
  return sortedTransactions.value.slice(
    (currentPage.value - 1) * itemsPerPage,
    currentPage.value * itemsPerPage
  )
})

const totalPages = computed(() => {
  return Math.ceil(sortedTransactions.value.length / itemsPerPage) || 1
})

const startEntry = computed(() => {
  return sortedTransactions.value.length === 0 ? 0 : (currentPage.value - 1) * itemsPerPage + 1
})

const endEntry = computed(() => {
  return Math.min(currentPage.value * itemsPerPage, sortedTransactions.value.length)
})

const visiblePages = computed(() => {
  const maxVisible = 5
  let start = Math.max(1, currentPage.value - Math.floor(maxVisible / 2))
  const end = Math.min(totalPages.value, start + maxVisible - 1)
  if (end - start + 1 < maxVisible) {
    start = Math.max(1, end - maxVisible + 1)
  }
  return Array.from({ length: end - start + 1 }, (_, i) => start + i)
})

const previousButtonClass = computed(() => {
  return `shadow-theme-xs flex items-center gap-2 rounded-lg border border-gray-300 bg-white p-2 text-gray-700 hover:bg-gray-50 hover:text-gray-800 sm:p-2.5 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-white/[0.03] dark:hover:text-gray-200 ${
    currentPage.value === 1 ? "opacity-50 cursor-not-allowed" : ""
  }`
})

const nextButtonClass = computed(() => {
  return `shadow-theme-xs flex items-center gap-2 rounded-lg border border-gray-300 bg-white p-2 text-gray-700 hover:bg-gray-50 hover:text-gray-800 sm:p-2.5 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-white/[0.03] dark:hover:text-gray-200 ${
    currentPage.value === totalPages.value ? "opacity-50 cursor-not-allowed" : ""
  }`
})

const sortBy = (field: "customer" | "email" | "amount") => {
  if (sort.value.key === field) {
    sort.value.asc = !sort.value.asc
  } else {
    sort.value.key = field
    sort.value.asc = true
  }
  currentPage.value = 1
}

const goToPage = (page: number) => {
  if (page >= 1 && page <= totalPages.value) currentPage.value = page
}

const nextPage = () => {
  if (currentPage.value < totalPages.value) currentPage.value = currentPage.value + 1
}

const previousPage = () => {
  if (currentPage.value > 1) currentPage.value = currentPage.value - 1
}

const getStatusClass = (status: string) => {
  if (status === "Completed") {
    return "text-theme-xs rounded-full px-2 py-0.5 font-medium bg-success-50 dark:bg-success-500/15 text-success-700 dark:text-success-500"
  } else if (status === "Failed") {
    return "text-theme-xs rounded-full px-2 py-0.5 font-medium bg-error-50 text-error-600 dark:bg-error-500/15 dark:text-error-500"
  } else {
    return "text-theme-xs rounded-full px-2 py-0.5 font-medium bg-warning-50 text-warning-600 dark:bg-warning-500/15 dark:text-warning-500"
  }
}

const getSortIconClass = (field: string, isAsc: boolean) => {
  return sort.value.key === field && sort.value.asc === isAsc
    ? "text-gray-500"
    : "text-gray-300"
}

const getPageButtonClass = (page: number) => {
  return `flex h-10 w-10 items-center justify-center rounded-lg text-sm font-medium ${
    page === currentPage.value
      ? "bg-brand-500 text-white"
      : "hover:bg-brand-500 text-gray-700 hover:text-white dark:text-gray-400 dark:hover:text-white"
  }`
}

// Menu action functions
const downloadReceipt = (transactionId: number) => {
  console.log('Downloading receipt for transaction:', transactionId)
  // TODO: Implement receipt download functionality
}

const refundTransaction = (transactionId: number) => {
  if (confirm('Are you sure you want to process a refund for this transaction?')) {
    const transaction = transactions.value.find(t => t.id === transactionId)
    if (transaction) {
      transaction.status = 'Failed' // Update status to indicate refund
      console.log('Processing refund for transaction:', transactionId)
      // TODO: Implement actual refund processing
    }
  }
}
</script>
