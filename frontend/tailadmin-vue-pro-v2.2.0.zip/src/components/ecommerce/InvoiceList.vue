<template>
  <div class="rounded-2xl border border-gray-200 bg-white p-6 dark:border-gray-800 dark:bg-white/[0.03]">
    <div class="mb-6 flex items-center justify-between">
      <h3 class="text-lg font-semibold text-gray-800 dark:text-white">
        Invoices
      </h3>
      <router-link
        to="/create-invoice"
        class="inline-flex items-center rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white transition hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600"
      >
        <svg class="mr-2 h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
        </svg>
        Create Invoice
      </router-link>
    </div>

    <div class="overflow-x-auto">
      <table class="w-full table-auto">
        <thead>
          <tr class="border-b border-gray-200 text-left dark:border-gray-800">
            <th class="py-3 font-medium text-gray-600 dark:text-gray-400">Invoice ID</th>
            <th class="py-3 font-medium text-gray-600 dark:text-gray-400">Customer</th>
            <th class="py-3 font-medium text-gray-600 dark:text-gray-400">Date</th>
            <th class="py-3 font-medium text-gray-600 dark:text-gray-400">Amount</th>
            <th class="py-3 font-medium text-gray-600 dark:text-gray-400">Status</th>
            <th class="py-3 font-medium text-gray-600 dark:text-gray-400">Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr
            v-for="invoice in invoices"
            :key="invoice.id"
            class="border-b border-gray-200 transition-colors hover:bg-gray-50 dark:border-gray-800 dark:hover:bg-gray-800/50"
          >
            <td class="py-4 font-medium text-gray-800 dark:text-white">
              {{ invoice.id }}
            </td>
            <td class="py-4 text-gray-600 dark:text-gray-400">
              {{ invoice.customer }}
            </td>
            <td class="py-4 text-gray-600 dark:text-gray-400">
              {{ invoice.date }}
            </td>
            <td class="py-4 font-medium text-gray-800 dark:text-white">
              {{ invoice.amount }}
            </td>
            <td class="py-4">
              <span
                :class="[
                  'inline-flex rounded-full px-2 py-1 text-xs font-medium',
                  invoice.status === 'Paid'
                    ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400'
                    : invoice.status === 'Pending'
                    ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400'
                    : 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400'
                ]"
              >
                {{ invoice.status }}
              </span>
            </td>
            <td class="py-4">
              <router-link
                :to="`/single-invoice/${invoice.id}`"
                class="text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300"
              >
                View
              </router-link>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'

interface Invoice {
  id: string
  customer: string
  date: string
  amount: string
  status: 'Paid' | 'Pending' | 'Overdue'
}

const invoices = ref<Invoice[]>([
  { id: 'INV-001', customer: 'John Doe', date: 'Feb 15, 2024', amount: '$1,250.00', status: 'Paid' },
  { id: 'INV-002', customer: 'Jane Smith', date: 'Feb 14, 2024', amount: '$890.00', status: 'Pending' },
  { id: 'INV-003', customer: 'Bob Johnson', date: 'Feb 13, 2024', amount: '$2,100.00', status: 'Paid' },
  { id: 'INV-004', customer: 'Alice Brown', date: 'Feb 12, 2024', amount: '$750.00', status: 'Overdue' },
])
</script>
