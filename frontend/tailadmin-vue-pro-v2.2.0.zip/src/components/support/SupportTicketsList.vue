<template>
  <div class="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-white/[0.03]">
    <!-- Header -->
    <div class="flex items-center justify-between border-b border-gray-200 px-5 py-4 dark:border-gray-800">
      <div>
        <h3 class="text-lg font-semibold text-gray-800 dark:text-white/90">
          Support Tickets
        </h3>
        <p class="text-sm text-gray-500 dark:text-gray-400">
          Your most recent support tickets list
        </p>
      </div>
      <div class="flex gap-3.5">
        <!-- Status Filter -->
        <div class="hidden h-11 items-center gap-0.5 rounded-lg bg-gray-100 p-0.5 lg:inline-flex dark:bg-gray-900">
          <button
            v-for="status in statusOptions"
            :key="status"
            @click="selectedStatus = status"
            :class="[
              'text-theme-sm h-10 rounded-md px-3 py-2 font-medium hover:text-gray-900 dark:hover:text-white',
              selectedStatus === status
                ? 'shadow-theme-xs text-gray-900 dark:text-white bg-white dark:bg-gray-800'
                : 'text-gray-500 dark:text-gray-400'
            ]"
          >
            {{ status }}
          </button>
        </div>
        <div class="hidden flex-col gap-3 sm:flex sm:flex-row sm:items-center">
          <!-- Search Input -->
          <div class="relative">
            <span class="absolute top-1/2 left-4 -translate-y-1/2 text-gray-500 dark:text-gray-400">
              <svg
                class="fill-current"
                width="20"
                height="20"
                viewBox="0 0 20 20"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  fill-rule="evenodd"
                  clip-rule="evenodd"
                  d="M3.04199 9.37363C3.04199 5.87693 5.87735 3.04199 9.37533 3.04199C12.8733 3.04199 15.7087 5.87693 15.7087 9.37363C15.7087 12.8703 12.8733 15.7053 9.37533 15.7053C5.87735 15.7053 3.04199 12.8703 3.04199 9.37363ZM9.37533 1.54199C5.04926 1.54199 1.54199 5.04817 1.54199 9.37363C1.54199 13.6991 5.04926 17.2053 9.37533 17.2053C11.2676 17.2053 13.0032 16.5344 14.3572 15.4176L17.1773 18.238C17.4702 18.5309 17.945 18.5309 18.2379 18.238C18.5308 17.9451 18.5309 17.4703 18.238 17.1773L15.4182 14.3573C16.5367 13.0033 17.2087 11.2669 17.2087 9.37363C17.2087 5.04817 13.7014 1.54199 9.37533 1.54199Z"
                  fill=""
                />
              </svg>
            </span>
            <input
              v-model="searchQuery"
              type="text"
              placeholder="Search..."
              class="dark:bg-dark-900 shadow-theme-xs focus:border-brand-300 focus:ring-brand-500/10 dark:focus:border-brand-800 h-11 w-full rounded-lg border border-gray-300 bg-transparent py-2.5 pr-4 pl-11 text-sm text-gray-800 placeholder:text-gray-400 focus:ring-3 focus:outline-hidden xl:w-[300px] dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:placeholder:text-white/30"
            />
          </div>
          <!-- Filter Dropdown -->
          <div class="relative filter-dropdown">
            <button
              @click="showFilter = !showFilter"
              type="button"
              class="shadow-theme-xs flex h-11 w-full items-center justify-center gap-2 rounded-lg border border-gray-300 bg-white px-4 py-2.5 text-sm font-medium text-gray-700 sm:w-auto sm:min-w-[100px] dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="20"
                height="20"
                viewBox="0 0 20 20"
                fill="none"
              >
                <path
                  d="M14.6537 5.90414C14.6537 4.48433 13.5027 3.33331 12.0829 3.33331C10.6631 3.33331 9.51206 4.48433 9.51204 5.90415M14.6537 5.90414C14.6537 7.32398 13.5027 8.47498 12.0829 8.47498C10.663 8.47498 9.51204 7.32398 9.51204 5.90415M14.6537 5.90414L17.7087 5.90411M9.51204 5.90415L2.29199 5.90411M5.34694 14.0958C5.34694 12.676 6.49794 11.525 7.91777 11.525C9.33761 11.525 10.4886 12.676 10.4886 14.0958M5.34694 14.0958C5.34694 15.5156 6.49794 16.6666 7.91778 16.6666C9.33761 16.6666 10.4886 15.5156 10.4886 14.0958M5.34694 14.0958L2.29199 14.0958M10.4886 14.0958L17.7087 14.0958"
                  stroke="currentColor"
                  stroke-width="1.5"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                />
              </svg>
              Filter
            </button>
            <div v-if="showFilter" class="absolute right-0 z-10 mt-2 w-56 rounded-lg border border-gray-200 bg-white p-4 shadow-lg dark:border-gray-700 dark:bg-gray-800">
              <div class="mb-5">
                <label class="mb-2 block text-xs font-medium text-gray-700 dark:text-gray-300">
                  Category
                </label>
                <input
                  v-model="filterData.category"
                  type="text"
                  name="category"
                  class="dark:bg-dark-900 shadow-theme-xs focus:border-brand-300 focus:ring-brand-500/10 dark:focus:border-brand-800 h-10 w-full rounded-lg border border-gray-300 bg-transparent px-4 py-2.5 text-sm text-gray-800 placeholder:text-gray-400 focus:ring-3 focus:outline-hidden dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:placeholder:text-white/30"
                  placeholder="Search category..."
                />
              </div>
              <div class="mb-5">
                <label class="mb-2 block text-xs font-medium text-gray-700 dark:text-gray-300">
                  Company
                </label>
                <input
                  v-model="filterData.company"
                  type="text"
                  name="company"
                  class="dark:bg-dark-900 shadow-theme-xs focus:border-brand-300 focus:ring-brand-500/10 dark:focus:border-brand-800 h-10 w-full rounded-lg border border-gray-300 bg-transparent px-4 py-2.5 text-sm text-gray-800 placeholder:text-gray-400 focus:ring-3 focus:outline-hidden dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:placeholder:text-white/30"
                  placeholder="Search company..."
                />
              </div>
              <button
                @click="showFilter = false"
                class="bg-brand-500 hover:bg-brand-600 h-10 w-full rounded-lg px-3 py-2 text-sm font-medium text-white"
              >
                Apply
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Table -->
    <div class="overflow-x-auto custom-scrollbar">
      <table class="w-full table-auto">
        <thead>
          <tr class="border-b border-gray-200 dark:border-gray-800">
            <th class="px-4 py-3 whitespace-nowrap">
              <div class="flex w-full cursor-pointer items-center justify-between">
                <div class="flex items-center gap-3">
                  <label class="flex cursor-pointer items-center text-sm font-medium text-gray-700 select-none dark:text-gray-400">
                    <span class="relative">
                      <input
                        v-model="selectAll"
                        @change="handleToggleAll"
                        type="checkbox"
                        class="sr-only"
                      />
                      <span
                        :class="[
                          'flex h-4 w-4 items-center justify-center rounded-sm border-[1.25px]',
                          selectAll
                            ? 'border-brand-500 bg-brand-500'
                            : 'bg-transparent border-gray-300 dark:border-gray-700'
                        ]"
                      >
                        <span :class="selectAll ? '' : 'opacity-0'">
                          <svg
                            width="12"
                            height="12"
                            viewBox="0 0 12 12"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                          >
                            <path
                              d="M10 3L4.5 8.5L2 6"
                              stroke="white"
                              stroke-width="1.6666"
                              stroke-linecap="round"
                              stroke-linejoin="round"
                            />
                          </svg>
                        </span>
                      </span>
                    </span>
                  </label>
                  <p class="text-theme-xs font-medium text-gray-700 dark:text-gray-400">
                    Ticket ID
                  </p>
                </div>
              </div>
            </th>
            <th class="px-4 py-3 text-left text-xs font-medium whitespace-nowrap text-gray-700 dark:text-gray-400">
              <div
                @click="handleSort('name')"
                class="flex cursor-pointer items-center justify-between gap-3"
              >
                <p class="text-theme-xs font-medium text-gray-700 dark:text-gray-400">
                  Requested By
                </p>
                <span class="flex flex-col gap-0.5">
                  <svg
                    :class="[
                      sortBy === 'name' && sortAsc
                        ? 'text-gray-500 dark:text-gray-300'
                        : 'text-gray-300 dark:text-gray-400'
                    ]"
                    width="8"
                    height="5"
                    viewBox="0 0 8 5"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M4.40962 0.585167C4.21057 0.300808 3.78943 0.300807 3.59038 0.585166L1.05071 4.21327C0.81874 4.54466 1.05582 5 1.46033 5H6.53967C6.94418 5 7.18126 4.54466 6.94929 4.21327L4.40962 0.585167Z"
                      fill="currentColor"
                    />
                  </svg>
                  <svg
                    :class="[
                      sortBy === 'name' && !sortAsc
                        ? 'text-gray-500 dark:text-gray-300'
                        : 'text-gray-300 dark:text-gray-400'
                    ]"
                    width="8"
                    height="5"
                    viewBox="0 0 8 5"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M4.40962 4.41483C4.21057 4.69919 3.78943 4.69919 3.59038 4.41483L1.05071 0.786732C0.81874 0.455343 1.05582 0 1.46033 0H6.53967C6.94418 0 7.18126 0.455342 6.94929 0.786731L4.40962 4.41483Z"
                      fill="currentColor"
                    />
                  </svg>
                </span>
              </div>
            </th>
            <th class="px-4 py-3 text-left text-xs font-medium whitespace-nowrap text-gray-700 dark:text-gray-400">
              Subject
            </th>
            <th class="px-4 py-3 text-left text-xs font-medium whitespace-nowrap text-gray-700 dark:text-gray-400">
              <div
                @click="handleSort('date')"
                class="flex cursor-pointer items-center justify-between gap-3"
              >
                <p class="text-theme-xs font-medium text-gray-700 dark:text-gray-400">
                  Create Date
                </p>
                <span class="flex flex-col gap-0.5">
                  <svg
                    :class="[
                      sortBy === 'date' && sortAsc
                        ? 'text-gray-500 dark:text-gray-300'
                        : 'text-gray-300 dark:text-gray-400'
                    ]"
                    width="8"
                    height="5"
                    viewBox="0 0 8 5"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M4.40962 0.585167C4.21057 0.300808 3.78943 0.300807 3.59038 0.585166L1.05071 4.21327C0.81874 4.54466 1.05582 5 1.46033 5H6.53967C6.94418 5 7.18126 4.54466 6.94929 4.21327L4.40962 0.585167Z"
                      fill="currentColor"
                    />
                  </svg>
                  <svg
                    :class="[
                      sortBy === 'date' && !sortAsc
                        ? 'text-gray-500 dark:text-gray-300'
                        : 'text-gray-300 dark:text-gray-400'
                    ]"
                    width="8"
                    height="5"
                    viewBox="0 0 8 5"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M4.40962 4.41483C4.21057 4.69919 3.78943 4.69919 3.59038 4.41483L1.05071 0.786732C0.81874 0.455343 1.05582 0 1.46033 0H6.53967C6.94418 0 7.18126 0.455342 6.94929 0.786731L4.40962 4.41483Z"
                      fill="currentColor"
                    />
                  </svg>
                </span>
              </div>
            </th>
            <th class="px-4 py-3 text-left text-xs font-medium whitespace-nowrap text-gray-700 dark:text-gray-400">
              Status
            </th>
          </tr>
        </thead>
        <tbody class="divide-y divide-gray-200 dark:divide-gray-800">
          <tr
            v-for="ticket in paginatedTickets"
            :key="ticket.id"
            class="transition hover:bg-gray-50 dark:hover:bg-gray-900"
          >
            <td class="px-4 py-3 whitespace-nowrap">
              <div class="flex items-center gap-3">
                <label class="flex cursor-pointer items-center text-sm font-medium text-gray-700 select-none dark:text-gray-400">
                  <span class="relative">
                    <input
                      :value="ticket.id"
                      :checked="selected.includes(ticket.id)"
                      @change="handleToggleOne(ticket.id)"
                      type="checkbox"
                      class="sr-only"
                    />
                    <span
                      :class="[
                        'flex h-4 w-4 items-center justify-center rounded-sm border-[1.25px]',
                        selected.includes(ticket.id)
                          ? 'border-brand-500 bg-brand-500'
                          : 'bg-transparent border-gray-300 dark:border-gray-700'
                      ]"
                    >
                      <span :class="selected.includes(ticket.id) ? '' : 'opacity-0'">
                        <svg
                          width="12"
                          height="12"
                          viewBox="0 0 12 12"
                          fill="none"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path
                            d="M10 3L4.5 8.5L2 6"
                            stroke="white"
                            stroke-width="1.6666"
                            stroke-linecap="round"
                            stroke-linejoin="round"
                          />
                        </svg>
                      </span>
                    </span>
                  </span>
                </label>
                <p class="text-theme-xs font-medium text-gray-700 dark:text-gray-400">
                  {{ ticket.id }}
                </p>
              </div>
            </td>
            <td class="px-4 py-3 whitespace-nowrap">
              <div>
                <span class="text-sm font-medium text-gray-800 dark:text-white/90">
                  {{ ticket.name }}
                </span>
                <p class="text-sm text-gray-500 dark:text-gray-400">
                  {{ ticket.email }}
                </p>
              </div>
            </td>
            <td class="px-4 py-3 whitespace-nowrap">
              <p class="text-sm text-gray-700 dark:text-gray-400">
                {{ ticket.subject }}
              </p>
            </td>
            <td class="px-4 py-3 whitespace-nowrap">
              <p class="text-sm text-gray-700 dark:text-gray-400">
                {{ ticket.date }}
              </p>
            </td>
            <td class="px-4 py-3 whitespace-nowrap">
              <span
                :class="[ticket.statusClass, 'text-theme-xs rounded-full px-2 py-0.5 font-medium']"
              >
                {{ ticket.status }}
              </span>
            </td>
            <td class="px-4 py-3 whitespace-nowrap">
              <div class="flex items-center justify-center">
                <TableDropdown />
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- Pagination -->
    <div class="flex items-center flex-col sm:flex-row justify-between border-t border-gray-200 px-5 py-4 dark:border-gray-800">
      <div class="sm:p-0 pb-3">
        <span class="block text-sm font-medium text-gray-500 dark:text-gray-400">
          Showing
          <span class="text-gray-800 dark:text-white/90">
            {{ (currentPage - 1) * perPage + 1 }}
          </span>
          to
          <span class="text-gray-800 dark:text-white/90">
            {{ Math.min(currentPage * perPage, sortedTickets.length) }}
          </span>
          of
          <span class="text-gray-800 dark:text-white/90">
            {{ sortedTickets.length }}
          </span>
        </span>
      </div>
      <div class="flex items-center justify-between gap-2 sm:justify-normal bg-gray-50 sm:w-auto dark:sm:bg-transparent p-2 sm:p-0 w-full rounded-lg dark:bg-white/[0.03] sm:bg-transparent">
        <button
          @click="handlePrevPage"
          :disabled="currentPage === 1"
          class="shadow-theme-xs flex items-center gap-2 rounded-lg border border-gray-300 bg-white p-2 text-gray-700 hover:bg-gray-50 hover:text-gray-800 disabled:cursor-not-allowed disabled:opacity-50 sm:p-2.5 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-white/[0.03] dark:hover:text-gray-200"
        >
          <span>
            <svg
              class="fill-current"
              width="20"
              height="20"
              viewBox="0 0 20 20"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                fill-rule="evenodd"
                clip-rule="evenodd"
                d="M2.58203 9.99868C2.58174 10.1909 2.6549 10.3833 2.80152 10.53L7.79818 15.5301C8.09097 15.8231 8.56584 15.8233 8.85883 15.5305C9.15183 15.2377 9.152 14.7629 8.85921 14.4699L5.13911 10.7472L16.6665 10.7472C17.0807 10.7472 17.4165 10.4114 17.4165 9.99715C17.4165 9.58294 17.0807 9.24715 16.6665 9.24715L5.14456 9.24715L8.85919 5.53016C9.15199 5.23717 9.15184 4.7623 8.85885 4.4695C8.56587 4.1767 8.09099 4.17685 7.79819 4.46984L2.84069 9.43049C2.68224 9.568 2.58203 9.77087 2.58203 9.99715C2.58203 9.99766 2.58203 9.99817 2.58203 9.99868Z"
              />
            </svg>
          </span>
        </button>
        <span class="block text-sm font-medium text-gray-700 sm:hidden dark:text-gray-400">
          Page {{ currentPage }} of {{ totalPages }}
        </span>
        <ul class="hidden items-center gap-0.5 sm:flex">
          <li v-for="page in totalPages" :key="page">
            <a
              href="#"
              @click.prevent="handleGoToPage(page)"
              :class="[
                'flex h-10 w-10 items-center justify-center rounded-lg text-sm font-medium',
                currentPage === page
                  ? 'bg-brand-500 hover:bg-brand-500 text-white hover:text-white'
                  : 'text-gray-700 hover:bg-brand-500 hover:text-white dark:text-gray-400 dark:hover:text-white'
              ]"
            >
              {{ page }}
            </a>
          </li>
        </ul>
        <button
          @click="handleNextPage"
          :disabled="currentPage === totalPages"
          class="shadow-theme-xs flex items-center gap-2 rounded-lg border border-gray-300 bg-white p-2 text-gray-700 hover:bg-gray-50 hover:text-gray-800 disabled:cursor-not-allowed disabled:opacity-50 sm:p-2.5 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-white/[0.03] dark:hover:text-gray-200"
        >
          <span>
            <svg
              class="fill-current"
              width="20"
              height="20"
              viewBox="0 0 20 20"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                fill-rule="evenodd"
                clip-rule="evenodd"
                d="M17.4165 9.9986C17.4168 10.1909 17.3437 10.3832 17.197 10.53L12.2004 15.5301C11.9076 15.8231 11.4327 15.8233 11.1397 15.5305C10.8467 15.2377 10.8465 14.7629 11.1393 14.4699L14.8594 10.7472L3.33203 10.7472C2.91782 10.7472 2.58203 10.4114 2.58203 9.99715C2.58203 9.58294 2.91782 9.24715 3.33203 9.24715L14.854 9.24715L11.1393 5.53016C10.8465 5.23717 10.8467 4.7623 11.1397 4.4695C11.4327 4.1767 11.9075 4.17685 12.2003 4.46984L17.1578 9.43049C17.3163 9.568 17.4165 9.77087 17.4165 9.99715C17.4165 9.99763 17.4165 9.99812 17.4165 9.9986Z"
              />
            </svg>
          </span>
        </button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted } from 'vue'
import TableDropdown from '@/components/common/TableDropdown.vue'

interface Ticket {
  id: string
  name: string
  email: string
  subject: string
  date: string
  status: 'Solved' | 'Pending'
  statusClass: string
}

interface FilterData {
  category: string
  company: string
}

// Reactive data
const tickets = ref<Ticket[]>([
  {
    id: '#323534',
    name: 'Lindsey Curtis',
    email: 'demoemail@gmail.com',
    subject: 'Issue with Dashboard Login Access',
    date: '12 Feb, 2027',
    status: 'Solved',
    statusClass: 'bg-success-50 dark:bg-success-500/15 text-success-700 dark:text-success-500',
  },
  {
    id: '#323535',
    name: 'Kaiya George',
    email: 'demoemail@gmail.com',
    subject: 'Billing Information Not Updating Properly',
    date: '13 Mar, 2027',
    status: 'Pending',
    statusClass: 'bg-warning-50 dark:bg-warning-500/15 text-warning-600 dark:text-warning-500',
  },
  {
    id: '#323536',
    name: 'Zain Geidt',
    email: 'demoemail@gmail.com',
    subject: 'Bug Found in Dark Mode Layout',
    date: '19 Mar, 2027',
    status: 'Pending',
    statusClass: 'bg-warning-50 dark:bg-warning-500/15 text-warning-600 dark:text-warning-500',
  },
  {
    id: '#323537',
    name: 'Abram Schleifer',
    email: 'demoemail@gmail.com',
    subject: 'Request to Add New Integration Feature',
    date: '25 Apr, 2027',
    status: 'Solved',
    statusClass: 'bg-success-50 dark:bg-success-500/15 text-success-700 dark:text-success-500',
  },
  {
    id: '#323538',
    name: 'Mia Chen',
    email: 'mia.chen@email.com',
    subject: 'Unable to Reset Password',
    date: '28 Apr, 2027',
    status: 'Pending',
    statusClass: 'bg-warning-50 dark:bg-warning-500/15 text-warning-600 dark:text-warning-500',
  },
  {
    id: '#323539',
    name: 'John Doe',
    email: 'john.doe@email.com',
    subject: 'Feature Request: Dark Mode',
    date: '30 Apr, 2027',
    status: 'Solved',
    statusClass: 'bg-success-50 dark:bg-success-500/15 text-success-700 dark:text-success-500',
  },
  {
    id: '#323540',
    name: 'Jane Smith',
    email: 'jane.smith@email.com',
    subject: 'Error 500 on Dashboard',
    date: '01 May, 2027',
    status: 'Pending',
    statusClass: 'bg-warning-50 dark:bg-warning-500/15 text-warning-600 dark:text-warning-500',
  },
  {
    id: '#323541',
    name: 'Carlos Ruiz',
    email: 'carlos.ruiz@email.com',
    subject: 'Cannot Download Invoice',
    date: '02 May, 2027',
    status: 'Solved',
    statusClass: 'bg-success-50 dark:bg-success-500/15 text-success-700 dark:text-success-500',
  },
  {
    id: '#323542',
    name: 'Emily Clark',
    email: 'emily.clark@email.com',
    subject: 'UI Bug in Mobile View',
    date: '03 May, 2027',
    status: 'Pending',
    statusClass: 'bg-warning-50 dark:bg-warning-500/15 text-warning-600 dark:text-warning-500',
  },
  {
    id: '#323543',
    name: 'Liam Wong',
    email: 'liam.wong@email.com',
    subject: 'Account Locked',
    date: '04 May, 2027',
    status: 'Solved',
    statusClass: 'bg-success-50 dark:bg-success-500/15 text-success-700 dark:text-success-500',
  },
  {
    id: '#323544',
    name: 'Sophia Patel',
    email: 'sophia.patel@email.com',
    subject: 'Integration Not Working',
    date: '05 May, 2027',
    status: 'Pending',
    statusClass: 'bg-warning-50 dark:bg-warning-500/15 text-warning-600 dark:text-warning-500',
  },
  {
    id: '#323545',
    name: 'Noah Kim',
    email: 'noah.kim@email.com',
    subject: 'Request for API Access',
    date: '06 May, 2027',
    status: 'Solved',
    statusClass: 'bg-success-50 dark:bg-success-500/15 text-success-700 dark:text-success-500',
  },
])

const statusOptions = ['All', 'Solved', 'Pending'] as const
const selectedStatus = ref<typeof statusOptions[number]>('All')
const searchQuery = ref('')
const filterData = ref<FilterData>({ category: '', company: '' })
const showFilter = ref(false)
const currentPage = ref(1)
const perPage = ref(10)
const sortBy = ref('')
const sortAsc = ref(true)
const selectAll = ref(false)
const selected = ref<string[]>([])

// Computed properties
const filteredTickets = computed(() => {
  return tickets.value
    .filter(ticket => selectedStatus.value === 'All' || ticket.status === selectedStatus.value)
    .filter(ticket =>
      ticket.subject.toLowerCase().includes(searchQuery.value.toLowerCase()) ||
      ticket.name.toLowerCase().includes(searchQuery.value.toLowerCase()) ||
      ticket.email.toLowerCase().includes(searchQuery.value.toLowerCase())
    )
    .filter(ticket =>
      ticket.subject.toLowerCase().includes(filterData.value.category.toLowerCase()) &&
      ticket.email.toLowerCase().includes(filterData.value.company.toLowerCase())
    )
})

const sortedTickets = computed(() => {
  const sorted = [...filteredTickets.value]
  if (sortBy.value) {
    sorted.sort((a, b) => {
      let valA: string | number | Date = a[sortBy.value as keyof Ticket]
      let valB: string | number | Date = b[sortBy.value as keyof Ticket]
      if (sortBy.value === 'date') {
        const parse = (v: string) => new Date(v.replace(/(\d{2}) (\w+), (\d{4})/, '$2 $1, $3'))
        valA = parse(valA as string)
        valB = parse(valB as string)
      } else {
        valA = (valA as string).toLowerCase()
        valB = (valB as string).toLowerCase()
      }
      if (valA < valB) return sortAsc.value ? -1 : 1
      if (valA > valB) return sortAsc.value ? 1 : -1
      return 0
    })
  }
  return sorted
})

const totalPages = computed(() => Math.ceil(sortedTickets.value.length / perPage.value))
const paginatedTickets = computed(() =>
  sortedTickets.value.slice((currentPage.value - 1) * perPage.value, currentPage.value * perPage.value)
)

// Methods
const handleSort = (field: string) => {
  if (sortBy.value === field) {
    sortAsc.value = !sortAsc.value
  } else {
    sortBy.value = field
    sortAsc.value = true
  }
}

const handlePrevPage = () => {
  if (currentPage.value > 1) currentPage.value--
}

const handleNextPage = () => {
  if (currentPage.value < totalPages.value) currentPage.value++
}

const handleGoToPage = (page: number) => {
  if (page >= 1 && page <= totalPages.value) currentPage.value = page
}

const handleToggleAll = () => {
  if (selectAll.value) {
    selected.value = []
  } else {
    selected.value = paginatedTickets.value.map(ticket => ticket.id)
  }
  selectAll.value = !selectAll.value
}

const handleToggleOne = (id: string) => {
  const newSelected = selected.value.includes(id)
    ? selected.value.filter(i => i !== id)
    : [...selected.value, id]
  selected.value = newSelected
  selectAll.value = newSelected.length === paginatedTickets.value.length
}

const handleClickOutside = (event: MouseEvent) => {
  if (showFilter.value &&
      event.target &&
      (event.target as Element).closest &&
      !(event.target as Element).closest('.filter-dropdown')) {
    showFilter.value = false
  }
}

onMounted(() => {
  document.addEventListener('click', handleClickOutside)
})

onUnmounted(() => {
  document.removeEventListener('click', handleClickOutside)
})
</script>
