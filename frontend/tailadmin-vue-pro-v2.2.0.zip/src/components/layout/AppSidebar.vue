<template>
  <aside
    :class="[
      'fixed flex flex-col xl:mt-0 top-0 px-5 left-0 bg-white dark:bg-gray-900 dark:border-gray-800 text-gray-900 h-full transition-all duration-300 ease-in-out z-50 border-r border-gray-200',
      {
        'w-[290px]': isExpanded || isMobileOpen || isHovered,
        'w-[90px]': !isExpanded && !isHovered,
        'translate-x-0': isMobileOpen,
        '-translate-x-full': !isMobileOpen,
        'xl:translate-x-0': true,
      },
    ]"
    @mouseenter="!isExpanded && (isHovered = true)"
    @mouseleave="isHovered = false"
  >
    <div :class="['py-8 flex', !isExpanded && !isHovered ? 'xl:justify-center' : 'justify-start']">
      <router-link to="/">
        <img
          v-if="isExpanded || isHovered || isMobileOpen"
          class="dark:hidden"
          src="/images/logo/logo.svg"
          alt="Logo"
          width="150"
          height="40"
        />
        <img
          v-if="isExpanded || isHovered || isMobileOpen"
          class="hidden dark:block"
          src="/images/logo/logo-dark.svg"
          alt="Logo"
          width="150"
          height="40"
        />
        <img v-else src="/images/logo/logo-icon.svg" alt="Logo" width="32" height="32" />
      </router-link>
    </div>
    <div class="flex flex-col overflow-y-auto duration-300 ease-linear no-scrollbar">
      <nav class="mb-6">
        <div class="flex flex-col gap-4">
          <!-- Main Menu Section -->
          <div>
            <h2
              :class="[
                'mb-4 text-xs uppercase flex leading-5 text-gray-400',
                !isExpanded && !isHovered ? 'xl:justify-center' : 'justify-start',
              ]"
            >
              <template v-if="isExpanded || isHovered || isMobileOpen">
                Menu
              </template>
              <HorizontalDots v-else />
            </h2>
            <ul class="flex flex-col gap-1">
              <li v-for="(nav, index) in menuItems" :key="nav.name">
                <button
                  v-if="nav.subItems"
                  @click="toggleSubmenu(index, 'main')"
                  :class="[
                    'menu-item group cursor-pointer',
                    {
                      'menu-item-active': isSubmenuOpen(index, 'main'),
                      'menu-item-inactive': !isSubmenuOpen(index, 'main'),
                    },
                    !isExpanded && !isHovered ? 'lg:justify-center' : 'lg:justify-start',
                  ]"
                >
                  <span
                    :class="[
                      isSubmenuOpen(index, 'main')
                        ? 'menu-item-icon-active'
                        : 'menu-item-icon-inactive',
                    ]"
                  >
                    <component :is="nav.icon" />
                  </span>
                  <span v-if="isExpanded || isHovered || isMobileOpen" class="menu-item-text">{{
                    nav.name
                  }}</span>
                  <span
                    v-if="nav.new && (isExpanded || isHovered || isMobileOpen)"
                    :class="[
                      'ml-auto absolute right-10',
                      isSubmenuOpen(index, 'main')
                        ? 'menu-dropdown-badge-active'
                        : 'menu-dropdown-badge-inactive',
                      'menu-dropdown-badge',
                    ]"
                  >
                    new
                  </span>
                  <ChevronDownIcon
                    v-if="isExpanded || isHovered || isMobileOpen"
                    :class="[
                      'ml-auto w-5 h-5 transition-transform duration-200',
                      { 'rotate-180 text-brand-500': isSubmenuOpen(index, 'main') },
                    ]"
                  />
                </button>
                <router-link
                  v-else-if="nav.path"
                  :to="nav.path"
                  :class="[
                    'menu-item group',
                    {
                      'menu-item-active': isActive(nav.path),
                      'menu-item-inactive': !isActive(nav.path),
                    },
                  ]"
                >
                  <span
                    :class="[
                      isActive(nav.path) ? 'menu-item-icon-active' : 'menu-item-icon-inactive',
                    ]"
                  >
                    <component :is="nav.icon" />
                  </span>
                  <span v-if="isExpanded || isHovered || isMobileOpen" class="menu-item-text">{{
                    nav.name
                  }}</span>
                </router-link>
                <div
                  v-if="nav.subItems && (isExpanded || isHovered || isMobileOpen)"
                  :class="[
                    'transition-all duration-300',
                    isSubmenuOpen(index, 'main') ? 'block' : 'hidden',
                  ]"
                >
                  <ul class="mt-2 space-y-1 ml-9">
                    <li v-for="subItem in nav.subItems" :key="subItem.name">
                      <router-link
                        :to="subItem.path"
                        :class="[
                          'menu-dropdown-item',
                          {
                            'menu-dropdown-item-active': isActive(subItem.path),
                            'menu-dropdown-item-inactive': !isActive(subItem.path),
                          },
                        ]"
                      >
                        {{ subItem.name }}
                        <span class="flex items-center gap-1 ml-auto">
                          <span
                            v-if="subItem.new"
                            :class="[
                              'ml-auto',
                              isActive(subItem.path)
                                ? 'menu-dropdown-badge-active'
                                : 'menu-dropdown-badge-inactive',
                              'menu-dropdown-badge',
                            ]"
                          >
                            new
                          </span>
                          <span
                            v-if="subItem.pro"
                            :class="[
                              'ml-auto',
                              isActive(subItem.path)
                                ? 'menu-dropdown-badge-pro-active'
                                : 'menu-dropdown-badge-pro-inactive',
                              'menu-dropdown-badge-pro',
                            ]"
                          >
                            pro
                          </span>
                        </span>
                      </router-link>
                    </li>
                  </ul>
                </div>
              </li>
            </ul>
          </div>

          <!-- Support Section -->
          <div>
            <h2
              :class="[
                'mb-4 text-xs uppercase flex leading-5 text-gray-400',
                !isExpanded && !isHovered ? 'xl:justify-center' : 'justify-start',
              ]"
            >
              <template v-if="isExpanded || isHovered || isMobileOpen">
                Support
              </template>
              <HorizontalDots v-else />
            </h2>
            <ul class="flex flex-col gap-1">
              <li v-for="(nav, index) in supportItems" :key="nav.name">
                <button
                  v-if="nav.subItems"
                  @click="toggleSubmenu(index, 'support')"
                  :class="[
                    'menu-item group cursor-pointer',
                    {
                      'menu-item-active': isSubmenuOpen(index, 'support'),
                      'menu-item-inactive': !isSubmenuOpen(index, 'support'),
                    },
                    !isExpanded && !isHovered ? 'lg:justify-center' : 'lg:justify-start',
                  ]"
                >
                  <span
                    :class="[
                      isSubmenuOpen(index, 'support')
                        ? 'menu-item-icon-active'
                        : 'menu-item-icon-inactive',
                    ]"
                  >
                    <component :is="nav.icon" />
                  </span>
                  <span v-if="isExpanded || isHovered || isMobileOpen" class="menu-item-text">{{
                    nav.name
                  }}</span>
                  <span
                    v-if="nav.new && (isExpanded || isHovered || isMobileOpen)"
                    :class="[
                      'ml-auto absolute right-10',
                      isSubmenuOpen(index, 'support')
                        ? 'menu-dropdown-badge-active'
                        : 'menu-dropdown-badge-inactive',
                      'menu-dropdown-badge',
                    ]"
                  >
                    new
                  </span>
                  <ChevronDownIcon
                    v-if="isExpanded || isHovered || isMobileOpen"
                    :class="[
                      'ml-auto w-5 h-5 transition-transform duration-200',
                      { 'rotate-180 text-brand-500': isSubmenuOpen(index, 'support') },
                    ]"
                  />
                </button>
                <router-link
                  v-else-if="nav.path"
                  :to="nav.path"
                  :class="[
                    'menu-item group',
                    {
                      'menu-item-active': isActive(nav.path),
                      'menu-item-inactive': !isActive(nav.path),
                    },
                  ]"
                >
                  <span
                    :class="[
                      isActive(nav.path) ? 'menu-item-icon-active' : 'menu-item-icon-inactive',
                    ]"
                  >
                    <component :is="nav.icon" />
                  </span>
                  <span v-if="isExpanded || isHovered || isMobileOpen" class="menu-item-text">{{
                    nav.name
                  }}</span>
                </router-link>
                <div
                  v-if="nav.subItems && (isExpanded || isHovered || isMobileOpen)"
                  :class="[
                    'transition-all duration-300',
                    isSubmenuOpen(index, 'support') ? 'block' : 'hidden',
                  ]"
                >
                  <ul class="mt-2 space-y-1 ml-9">
                    <li v-for="subItem in nav.subItems" :key="subItem.name">
                      <router-link
                        :to="subItem.path"
                        :class="[
                          'menu-dropdown-item',
                          {
                            'menu-dropdown-item-active': isActive(subItem.path),
                            'menu-dropdown-item-inactive': !isActive(subItem.path),
                          },
                        ]"
                      >
                        {{ subItem.name }}
                        <span class="flex items-center gap-1 ml-auto">
                          <span
                            v-if="subItem.new"
                            :class="[
                              'ml-auto',
                              isActive(subItem.path)
                                ? 'menu-dropdown-badge-active'
                                : 'menu-dropdown-badge-inactive',
                              'menu-dropdown-badge',
                            ]"
                          >
                            new
                          </span>
                          <span
                            v-if="subItem.pro"
                            :class="[
                              'ml-auto',
                              isActive(subItem.path)
                                ? 'menu-dropdown-badge-pro-active'
                                : 'menu-dropdown-badge-pro-inactive',
                              'menu-dropdown-badge-pro',
                            ]"
                          >
                            pro
                          </span>
                        </span>
                      </router-link>
                    </li>
                  </ul>
                </div>
              </li>
            </ul>
          </div>

          <!-- Others Section -->
          <div>
            <h2
              :class="[
                'mb-4 text-xs uppercase flex leading-5 text-gray-400',
                !isExpanded && !isHovered ? 'xl:justify-center' : 'justify-start',
              ]"
            >
              <template v-if="isExpanded || isHovered || isMobileOpen">
                Others
              </template>
              <HorizontalDots v-else />
            </h2>
            <ul class="flex flex-col gap-1">
              <li v-for="(nav, index) in othersItems" :key="nav.name">
                <button
                  v-if="nav.subItems"
                  @click="toggleSubmenu(index, 'others')"
                  :class="[
                    'menu-item group cursor-pointer',
                    {
                      'menu-item-active': isSubmenuOpen(index, 'others'),
                      'menu-item-inactive': !isSubmenuOpen(index, 'others'),
                    },
                    !isExpanded && !isHovered ? 'lg:justify-center' : 'lg:justify-start',
                  ]"
                >
                  <span
                    :class="[
                      isSubmenuOpen(index, 'others')
                        ? 'menu-item-icon-active'
                        : 'menu-item-icon-inactive',
                    ]"
                  >
                    <component :is="nav.icon" />
                  </span>
                  <span v-if="isExpanded || isHovered || isMobileOpen" class="menu-item-text">{{
                    nav.name
                  }}</span>
                  <ChevronDownIcon
                    v-if="isExpanded || isHovered || isMobileOpen"
                    :class="[
                      'ml-auto w-5 h-5 transition-transform duration-200',
                      { 'rotate-180 text-brand-500': isSubmenuOpen(index, 'others') },
                    ]"
                  />
                </button>
                <router-link
                  v-else-if="nav.path"
                  :to="nav.path"
                  :class="[
                    'menu-item group',
                    {
                      'menu-item-active': isActive(nav.path),
                      'menu-item-inactive': !isActive(nav.path),
                    },
                  ]"
                >
                  <span
                    :class="[
                      isActive(nav.path) ? 'menu-item-icon-active' : 'menu-item-icon-inactive',
                    ]"
                  >
                    <component :is="nav.icon" />
                  </span>
                  <span v-if="isExpanded || isHovered || isMobileOpen" class="menu-item-text">{{
                    nav.name
                  }}</span>
                </router-link>
                <div
                  v-if="nav.subItems && (isExpanded || isHovered || isMobileOpen)"
                  :class="[
                    'transition-all duration-300',
                    isSubmenuOpen(index, 'others') ? 'block' : 'hidden',
                  ]"
                >
                  <ul class="mt-2 space-y-1 ml-9">
                    <li v-for="subItem in nav.subItems" :key="subItem.name">
                      <router-link
                        :to="subItem.path"
                        :class="[
                          'menu-dropdown-item',
                          {
                            'menu-dropdown-item-active': isActive(subItem.path),
                            'menu-dropdown-item-inactive': !isActive(subItem.path),
                          },
                        ]"
                      >
                        {{ subItem.name }}
                        <span class="flex items-center gap-1 ml-auto">
                          <span
                            v-if="subItem.new"
                            :class="[
                              'ml-auto',
                              isActive(subItem.path)
                                ? 'menu-dropdown-badge-active'
                                : 'menu-dropdown-badge-inactive',
                              'menu-dropdown-badge',
                            ]"
                          >
                            new
                          </span>
                          <span
                            v-if="subItem.pro"
                            :class="[
                              'ml-auto',
                              isActive(subItem.path)
                                ? 'menu-dropdown-badge-pro-active'
                                : 'menu-dropdown-badge-pro-inactive',
                              'menu-dropdown-badge-pro',
                            ]"
                          >
                            pro
                          </span>
                        </span>
                      </router-link>
                    </li>
                  </ul>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <SidebarWidget v-if="isExpanded || isHovered || isMobileOpen" />
    </div>
  </aside>
</template>

<script setup lang="ts">
import { ref, watch, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import type { Component } from 'vue'

import {
  GridIcon,
  CalenderIcon,
  UserCircleIcon,
  TaskIcon,
  ChatIcon,
  MailIcon,
  PieChartIcon,
  ChevronDownIcon,
  PageIcon,
  TableIcon,
  ListIcon,
  PlugInIcon,
  HorizontalDots,
  AiIcon,
  CartIcon,
  CallIcon,
} from '../../icons'
import SidebarWidget from './SidebarWidget.vue'
import BoxCubeIcon from '@/icons/BoxCubeIcon.vue'
import { useSidebar } from '@/composables/useSidebar'

// Types
interface SubMenuItem {
  name: string
  path: string
  new?: boolean
  pro?: boolean
}

interface MenuItem {
  icon: Component
  name: string
  path?: string
  new?: boolean
  subItems?: SubMenuItem[]
}

const route = useRoute()

const { isExpanded, isMobileOpen, isHovered } = useSidebar()

// State for submenu handling
const openSubmenu = ref<string | null>(null)

// Menu items structure - matching Next.js version exactly
const menuItems: MenuItem[] = [
  {
    icon: GridIcon,
    name: 'Dashboard',
    subItems: [
      { name: 'Ecommerce', path: '/' },
      { name: 'Analytics', path: '/analytics' },
      { name: 'Marketing', path: '/marketing' },
      { name: 'CRM', path: '/crm' },
      { name: 'Stocks', path: '/stocks' },
      { name: 'SaaS', path: '/saas', new: true },
      { name: 'Logistics', path: '/logistics', new: true },
    ],
  },
  {
    name: 'AI Assistant',
    icon: AiIcon,
    new: true,
    subItems: [
      { name: 'Text Generator', path: '/ai/text-generator' },
      { name: 'Image Generator', path: '/ai/image-generator' },
      { name: 'Code Generator', path: '/ai/code-generator' },
      { name: 'Video Generator', path: '/ai/video-generator' },
    ],
  },
  {
    name: 'E-commerce',
    icon: CartIcon,
    new: true,
    subItems: [
      { name: 'Products', path: '/products' },
      { name: 'Add Product', path: '/add-product' },
      { name: 'Billing', path: '/billing' },
      { name: 'Invoices', path: '/invoices' },
      { name: 'Single Invoice', path: '/single-invoice' },
      { name: 'Create Invoice', path: '/create-invoice' },
      { name: 'Transactions', path: '/transactions' },
      { name: 'Single Transaction', path: '/single-transaction' },
    ],
  },
  {
    icon: CalenderIcon,
    name: 'Calendar',
    path: '/calendar',
  },
  {
    icon: UserCircleIcon,
    name: 'User Profile',
    path: '/profile',
  },
  {
    name: 'Task',
    icon: TaskIcon,
    subItems: [
      { name: 'List', path: '/task-list' },
      { name: 'Kanban', path: '/task-kanban' },
    ],
  },
  {
    name: 'Forms',
    icon: ListIcon,
    subItems: [
      { name: 'Form Elements', path: '/form-elements' },
      { name: 'Form Layout', path: '/form-layout' },
    ],
  },
  {
    name: 'Tables',
    icon: TableIcon,
    subItems: [
      { name: 'Basic Tables', path: '/basic-tables' },
      { name: 'Data Tables', path: '/data-tables' },
    ],
  },
  {
    name: 'Pages',
    icon: PageIcon,
    subItems: [
      { name: 'File Manager', path: '/file-manager' },
      { name: 'Pricing Tables', path: '/pricing-tables' },
      { name: 'FAQ', path: '/faq' },
      { name: 'API Keys', path: '/api-keys', new: true },
      { name: 'Integrations', path: '/integrations', new: true },
      { name: 'Blank Page', path: '/blank' },
      { name: '404 Error', path: '/error-404' },
      { name: '500 Error', path: '/error-500' },
      { name: '503 Error', path: '/error-503' },
      { name: 'Coming Soon', path: '/coming-soon' },
      { name: 'Maintenance', path: '/maintenance' },
      { name: 'Success', path: '/success' },
    ],
  },
]

const supportItems: MenuItem[] = [
  {
    icon: ChatIcon,
    name: 'Chat',
    path: '/chat',
  },
  {
    icon: CallIcon,
    name: 'Support Ticket',
    new: true,
    subItems: [
      { name: 'Ticket List', path: '/support-tickets' },
      { name: 'Ticket Reply', path: '/ticket-reply' },
    ],
  },
  {
    icon: MailIcon,
    name: 'Email',
    subItems: [
      { name: 'Inbox', path: '/inbox' },
      { name: 'Details', path: '/inbox-details' },
    ],
  },
]

const othersItems: MenuItem[] = [
  {
    icon: PieChartIcon,
    name: 'Charts',
    subItems: [
      { name: 'Line Chart', path: '/line-chart' },
      { name: 'Bar Chart', path: '/bar-chart' },
      { name: 'Pie Chart', path: '/pie-chart' },
    ],
  },
  {
    icon: BoxCubeIcon,
    name: 'UI Elements',
    subItems: [
      { name: 'Alerts', path: '/alerts' },
      { name: 'Avatar', path: '/avatars' },
      { name: 'Badge', path: '/badge' },
      { name: 'Breadcrumb', path: '/breadcrumb', pro: true },
      { name: 'Buttons', path: '/buttons' },
      { name: 'Buttons Group', path: '/buttons-group', pro: true },
      { name: 'Cards', path: '/cards', pro: true },
      { name: 'Carousel', path: '/carousel', pro: true },
      { name: 'Dropdowns', path: '/dropdowns', pro: true },
      { name: 'Images', path: '/images' },
      { name: 'Links', path: '/links', pro: true },
      { name: 'List', path: '/list', pro: true },
      { name: 'Modals', path: '/modals', pro: true },
      { name: 'Notification', path: '/notifications', pro: true },
      { name: 'Pagination', path: '/pagination', pro: true },
      { name: 'Popovers', path: '/popovers', pro: true },
      { name: 'Progressbar', path: '/progress-bar', pro: true },
      { name: 'Ribbons', path: '/ribbons', pro: true },
      { name: 'Spinners', path: '/spinners', pro: true },
      { name: 'Tabs', path: '/tabs', pro: true },
      { name: 'Tooltips', path: '/tooltips', pro: true },
      { name: 'Videos', path: '/videos' },
    ],
  },
  {
    icon: PlugInIcon,
    name: 'Authentication',
    subItems: [
      { name: 'Sign In', path: '/signin' },
      { name: 'Sign Up', path: '/signup' },
      { name: 'Reset Password', path: '/reset-password' },
      { name: 'Two Step Verification', path: '/two-step-verification' },
    ],
  },
]

const isActive = (path: string) => route.path === path

const toggleSubmenu = (index: number, menuType: string) => {
  const key = `${menuType}-${index}`
  openSubmenu.value = openSubmenu.value === key ? null : key
}

const isSubmenuOpen = (index: number, menuType: string) => {
  const key = `${menuType}-${index}`
  return openSubmenu.value === key
}

// 自动展开包含当前路由的子菜单组
const autoExpandActiveSubmenu = () => {
  let submenuMatched = false

  // 检查主菜单
  menuItems.forEach((nav, index) => {
    if (nav.subItems) {
      nav.subItems.forEach((subItem) => {
        if (isActive(subItem.path)) {
          openSubmenu.value = `main-${index}`
          submenuMatched = true
        }
      })
    }
  })

  // 检查支持菜单
  if (!submenuMatched) {
    supportItems.forEach((nav, index) => {
      if (nav.subItems) {
        nav.subItems.forEach((subItem) => {
          if (isActive(subItem.path)) {
            openSubmenu.value = `support-${index}`
            submenuMatched = true
          }
        })
      }
    })
  }

  // 检查其他菜单
  if (!submenuMatched) {
    othersItems.forEach((nav, index) => {
      if (nav.subItems) {
        nav.subItems.forEach((subItem) => {
          if (isActive(subItem.path)) {
            openSubmenu.value = `others-${index}`
            submenuMatched = true
          }
        })
      }
    })
  }
}

// 监听路由变化，自动展开对应的子菜单
watch(() => route.path, () => {
  autoExpandActiveSubmenu()
}, { immediate: true })

// 组件挂载时也执行一次
onMounted(() => {
  autoExpandActiveSubmenu()
})
</script>
