<template>
  <div class="flex flex-col justify-between space-y-6 rounded-xl border border-gray-200 bg-white p-6 dark:border-gray-800 dark:bg-white/3">
    <div class="flex items-start justify-between">
      <div>
        <p class="text-sm text-gray-500 dark:text-gray-400">
          Total revenue earned
        </p>
        <h3 class="text-3xl font-medium text-gray-800 dark:text-white/90">
          $23,445,700
        </h3>
      </div>
      <div class="relative h-fit">
        <button @click="toggleDropdown" class="dropdown-toggle">
          <MoreDotIcon class="text-gray-400 hover:text-gray-700 dark:hover:text-gray-300" />
        </button>
        <div
          v-if="isOpen"
          class="absolute right-0 top-8 z-50 w-40 rounded-lg border border-gray-200 bg-white p-2 shadow-lg dark:border-gray-700 dark:bg-gray-800"
        >
          <button
            @click="handleDropdownAction('view')"
            class="flex w-full font-normal text-left text-gray-500 rounded-lg hover:bg-gray-100 hover:text-gray-700 dark:text-gray-400 dark:hover:bg-white/5 dark:hover:text-gray-300 px-3 py-2 text-sm"
          >
            View More
          </button>
          <button
            @click="handleDropdownAction('delete')"
            class="flex w-full font-normal text-left text-gray-500 rounded-lg hover:bg-gray-100 hover:text-gray-700 dark:text-gray-400 dark:hover:bg-white/5 dark:hover:text-gray-300 px-3 py-2 text-sm"
          >
            Delete
          </button>
        </div>
      </div>
    </div>
    <div class="flex items-center justify-between">
      <div>
        <p class="text-sm text-gray-500 dark:text-gray-400">
          Shipped quantities
        </p>
        <h3 class="text-3xl font-medium text-gray-800 dark:text-white/90">
          9,258
        </h3>
      </div>
      <div class="h-[60px] w-full max-w-[150px]">
        <!-- Simple SVG Chart -->
        <svg
          width="150"
          height="70"
          viewBox="0 0 150 70"
          class="w-full h-full"
        >
          <!-- Gradient definition -->
          <defs>
            <linearGradient id="revenueGradient" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" style="stop-color:#12B76A;stop-opacity:0.55" />
              <stop offset="100%" style="stop-color:#12B76A;stop-opacity:0" />
            </linearGradient>
          </defs>

          <!-- Area chart path -->
          <path
            :d="chartPath"
            fill="url(#revenueGradient)"
            stroke="#12B76A"
            stroke-width="1"
          />
        </svg>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'

const isOpen = ref(false)

// Chart data points (normalized to 0-70 height range)
const dataPoints = [30, 35, 31, 37, 24, 28, 29, 19, 26, 20, 18, 25, 15]

// Generate SVG path for the chart
const chartPath = computed(() => {
  const width = 150
  const height = 70
  const stepX = width / (dataPoints.length - 1)

  let path = `M 0,${height - dataPoints[0]}`

  for (let i = 1; i < dataPoints.length; i++) {
    const x = i * stepX
    const y = height - dataPoints[i]
    path += ` L ${x},${y}`
  }

  // Close the path to create the area
  path += ` L ${width},${height} L 0,${height} Z`

  return path
})

const toggleDropdown = () => {
  isOpen.value = !isOpen.value
}

const handleDropdownAction = (action: string) => {
  console.log(`Action: ${action}`)
  isOpen.value = false
}

// More Dot Icon Component
const MoreDotIcon = {
  props: ['class'],
  template: `
    <svg
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      :class="$props.class"
    >
      <path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M10.2441 6C10.2441 5.0335 11.0276 4.25 11.9941 4.25H12.0041C12.9706 4.25 13.7541 5.0335 13.7541 6C13.7541 6.9665 12.9706 7.75 12.0041 7.75H11.9941C11.0276 7.75 10.2441 6.9665 10.2441 6ZM10.2441 18C10.2441 17.0335 11.0276 16.25 11.9941 16.25H12.0041C12.9706 16.25 13.7541 17.0335 13.7541 18C13.7541 18.9665 12.9706 19.75 12.0041 19.75H11.9941C11.0276 19.75 10.2441 18.9665 10.2441 18ZM11.9941 10.25C11.0276 10.25 10.2441 11.0335 10.2441 12C10.2441 12.9665 11.0276 13.75 11.9941 13.75H12.0041C12.9706 13.75 13.7541 12.9665 13.7541 12C13.7541 11.0335 12.9706 10.25 12.0041 10.25H11.9941Z"
        fill="currentColor"
      />
    </svg>
  `
}
</script>
