<template>
  <div class="rounded-xl border border-gray-200 bg-white p-6 dark:border-gray-800 dark:bg-white/3">
    <div class="flex items-center justify-between gap-5">
      <div>
        <h3 class="text-lg font-semibold text-gray-800 dark:text-white/90">
          Delivery Statistics
        </h3>
        <p class="dark:text-gray-40 text-sm text-gray-500">
          Total number of deliveries 70.5K
        </p>
      </div>
      <div>
        <div class="relative z-20 bg-transparent">
          <select
            v-model="selectedPeriod"
            class="dark:bg-dark-900 shadow-theme-xs focus:border-brand-300 focus:ring-brand-500/10 dark:focus:border-brand-800 h-11 w-full appearance-none rounded-lg border border-gray-300 bg-transparent bg-none px-4 py-2.5 pr-11 text-sm text-gray-800 placeholder:text-gray-400 focus:ring-3 focus:outline-hidden dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:placeholder:text-white/30"
          >
            <option
              value="monthly"
              class="text-gray-700 dark:bg-gray-900 dark:text-gray-400"
            >
              Monthly
            </option>
            <option
              value="yearly"
              class="text-gray-700 dark:bg-gray-900 dark:text-gray-400"
            >
              Yearly
            </option>
          </select>
          <span class="pointer-events-none absolute top-1/2 right-4 z-30 -translate-y-1/2 text-gray-500 dark:text-gray-400">
            <svg
              class="stroke-current"
              width="20"
              height="20"
              viewBox="0 0 20 20"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M4.79175 7.396L10.0001 12.6043L15.2084 7.396"
                stroke=""
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </span>
        </div>
      </div>
    </div>

    <div>
      <div class="flex items-center gap-5 pt-5">
        <div class="flex items-center gap-1.5">
          <div class="bg-brand-200 h-2.5 w-2.5 rounded-full"></div>
          <p class="text-sm text-gray-500 dark:text-gray-400">Shipment</p>
        </div>
        <div class="flex items-center gap-1.5">
          <div class="bg-brand-500 h-2.5 w-2.5 rounded-full"></div>
          <p class="text-sm text-gray-500 dark:text-gray-400">Delivery</p>
        </div>
      </div>

      <!-- Chart Area -->
      <div class="w-full pt-4">
        <div class="relative">
          <!-- Chart Container with fixed height -->
          <div class="h-[235px] w-full">
            <!-- Y-axis labels -->
            <div class="absolute left-0 top-0 flex h-full flex-col justify-between py-4 text-xs text-gray-500">
              <span>100%</span>
              <span>75%</span>
              <span>50%</span>
              <span>25%</span>
              <span>0%</span>
            </div>

            <!-- Chart bars container -->
            <div class="ml-8 h-full">
              <div class="flex h-full items-end justify-between gap-1 border-b border-gray-200 dark:border-gray-700">
                <!-- Chart bars for each month -->
                <div
                  v-for="(month) in chartData"
                  :key="month.name"
                  class="relative flex w-full flex-col items-center gap-1"
                >
                  <!-- Bars -->
                  <div class="flex w-full items-end justify-center gap-0.5">
                    <!-- Shipment bar (light blue) -->
                    <div
                      class="w-3 bg-brand-200 rounded-t"
                      :style="{ height: `${month.shipment * 2}px` }"
                    ></div>
                    <!-- Delivery bar (dark blue) -->
                    <div
                      class="w-3 bg-brand-500 rounded-t"
                      :style="{ height: `${month.delivery * 2}px` }"
                    ></div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- X-axis labels - moved outside the chart container -->
          <div class="ml-8 flex justify-between pt-2 pb-4 text-xs text-gray-500">
            <span v-for="month in chartData" :key="month.name">{{ month.name }}</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'

const selectedPeriod = ref('monthly')

const chartData = [
  { name: 'Jan', shipment: 80, delivery: 90 },
  { name: 'Feb', shipment: 60, delivery: 50 },
  { name: 'Mar', shipment: 70, delivery: 65 },
  { name: 'Apr', shipment: 40, delivery: 25 },
  { name: 'May', shipment: 65, delivery: 78 },
  { name: 'Jun', shipment: 45, delivery: 68 },
  { name: 'Jul', shipment: 48, delivery: 75 },
  { name: 'Aug', shipment: 55, delivery: 90 },
  { name: 'Sep', shipment: 58, delivery: 30 },
  { name: 'Oct', shipment: 50, delivery: 70 },
  { name: 'Nov', shipment: 67, delivery: 90 },
  { name: 'Dec', shipment: 75, delivery: 95 }
]
</script>
