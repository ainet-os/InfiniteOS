<template>
  <div class="space-y5 rounded-xl border border-gray-200 bg-white p-6 dark:border-gray-800 dark:bg-white/3">
    <div class="flex items-start justify-between">
      <div>
        <h3 class="text-lg font-semibold text-gray-800 dark:text-white/90">
          Delivery Vehicles
        </h3>
        <p class="dark:text-gray-40 text-sm text-gray-500">
          Vehicles operating on the road
        </p>
      </div>
      <div class="relative h-fit">
        <button @click="toggleDropdown" class="dropdown-toggle">
          <svg
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            class="text-gray-400 hover:text-gray-700 dark:hover:text-gray-300"
          >
            <path
              fillRule="evenodd"
              clipRule="evenodd"
              d="M10.2441 6C10.2441 5.0335 11.0276 4.25 11.9941 4.25H12.0041C12.9706 4.25 13.7541 5.0335 13.7541 6C13.7541 6.9665 12.9706 7.75 12.0041 7.75H11.9941C11.0276 7.75 10.2441 6.9665 10.2441 6ZM10.2441 18C10.2441 17.0335 11.0276 16.25 11.9941 16.25H12.0041C12.9706 16.25 13.7541 17.0335 13.7541 18C13.7541 18.9665 12.9706 19.75 12.0041 19.75H11.9941C11.0276 19.75 10.2441 18.9665 10.2441 18ZM11.9941 10.25C11.0276 10.25 10.2441 11.0335 10.2441 12C10.2441 12.9665 11.0276 13.75 11.9941 13.75H12.0041C12.9706 13.75 13.7541 12.9665 13.7541 12C13.7541 11.0335 12.9706 10.25 12.0041 10.25H11.9941Z"
              fill="currentColor"
            />
          </svg>
        </button>
        <div
          v-if="isOpen"
          class="absolute right-0 top-8 z-50 w-40 rounded-lg border border-gray-200 bg-white p-2 shadow-lg dark:border-gray-700 dark:bg-gray-800"
        >
          <button
            @click="handleDropdownAction('view')"
            class="flex w-full font-normal text-left text-gray-500 rounded-lg hover:bg-gray-100 hover:text-gray-700 dark:text-gray-400 dark:hover:bg-white/5 dark:hover:text-gray-300 px-3 py-2 text-sm"
          >
            View More
          </button>
          <button
            @click="handleDropdownAction('delete')"
            class="flex w-full font-normal text-left text-gray-500 rounded-lg hover:bg-gray-100 hover:text-gray-700 dark:text-gray-400 dark:hover:bg-white/5 dark:hover:text-gray-300 px-3 py-2 text-sm"
          >
            Delete
          </button>
        </div>
      </div>
    </div>
    <div class="relative mt-5 flex justify-between">
      <div>
        <h3 class="mb-1 text-3xl font-medium text-gray-800 dark:text-white/90">
          29
        </h3>
        <p class="text-xs text-gray-500 dark:text-gray-400">
          <span class="text-success-600 font-medium">+3.85%</span>
          than last Week
        </p>
        <div class="mt-5 flex items-center gap-2">
          <div class="ring-success-500 flex h-6 w-6 items-center justify-center rounded-full ring-2 ring-inset">
            <div class="bg-success-500 h-2.5 w-2.5 rounded-full"></div>
          </div>
          <div>
            <span class="text-success-500 text-sm font-medium">
              On-route
            </span>
          </div>
        </div>
      </div>
      <div>
        <img
          width="160"
          height="132"
          class="absolute -right-6 -bottom-2"
          src="/images/logistics/truck.png"
          alt=""
        />
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'

const isOpen = ref(false)

const toggleDropdown = () => {
  isOpen.value = !isOpen.value
}

const handleDropdownAction = (action: string) => {
  console.log(`Action: ${action}`)
  isOpen.value = false
}
</script>
