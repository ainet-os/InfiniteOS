<template>
  <div class="rounded-xl bg-white p-4 dark:bg-gray-900">
    <div class="flex items-center justify-between">
      <div>
        <h3 class="text-lg font-semibold text-gray-800 dark:text-white/90">
          Tracking Delivery
        </h3>
        <p class="text-sm text-gray-500 dark:text-gray-400">
          Last viewed delivery history
        </p>
      </div>
      <div class="relative h-fit">
        <button @click="toggleDropdown" class="dropdown-toggle">
          <svg
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            class="text-gray-400 hover:text-gray-700 dark:hover:text-gray-300"
          >
            <path
              fillRule="evenodd"
              clipRule="evenodd"
              d="M10.2441 6C10.2441 5.0335 11.0276 4.25 11.9941 4.25H12.0041C12.9706 4.25 13.7541 5.0335 13.7541 6C13.7541 6.9665 12.9706 7.75 12.0041 7.75H11.9941C11.0276 7.75 10.2441 6.9665 10.2441 6ZM10.2441 18C10.2441 17.0335 11.0276 16.25 11.9941 16.25H12.0041C12.9706 16.25 13.7541 17.0335 13.7541 18C13.7541 18.9665 12.9706 19.75 12.0041 19.75H11.9941C11.0276 19.75 10.2441 18.9665 10.2441 18ZM11.9941 10.25C11.0276 10.25 10.2441 11.0335 10.2441 12C10.2441 12.9665 11.0276 13.75 11.9941 13.75H12.0041C12.9706 13.75 13.7541 12.9665 13.7541 12C13.7541 11.0335 12.9706 10.25 12.0041 10.25H11.9941Z"
              fill="currentColor"
            />
          </svg>
        </button>
        <div
          v-if="isOpen"
          class="absolute right-0 top-8 z-50 w-40 rounded-lg border border-gray-200 bg-white p-2 shadow-lg dark:border-gray-700 dark:bg-gray-800"
        >
          <button
            @click="handleDropdownAction('view')"
            class="flex w-full font-normal text-left text-gray-500 rounded-lg hover:bg-gray-100 hover:text-gray-700 dark:text-gray-400 dark:hover:bg-white/5 dark:hover:text-gray-300 px-3 py-2 text-sm"
          >
            View More
          </button>
          <button
            @click="handleDropdownAction('delete')"
            class="flex w-full font-normal text-left text-gray-500 rounded-lg hover:bg-gray-100 hover:text-gray-700 dark:text-gray-400 dark:hover:bg-white/5 dark:hover:text-gray-300 px-3 py-2 text-sm"
          >
            Delete
          </button>
        </div>
      </div>
    </div>
    <div class="mt-5">
      <iframe
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3650.5145053176284!2d90.42105717591272!3d23.800296778636472!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755c7e9f37a5a3d%3A0x41d7d1d02e1ed0e4!2sPimjo!5e0!3m2!1sen!2sbd!4v1751871078440!5m2!1sen!2sbd"
        width="303"
        height="180"
        loading="lazy"
        referrerPolicy="no-referrer-when-downgrade"
        class="!w-full rounded-xl border border-gray-200 grayscale dark:border-gray-800"
      ></iframe>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'

const isOpen = ref(false)

const toggleDropdown = () => {
  isOpen.value = !isOpen.value
}

const handleDropdownAction = (action: string) => {
  console.log(`Action: ${action}`)
  isOpen.value = false
}
</script>
